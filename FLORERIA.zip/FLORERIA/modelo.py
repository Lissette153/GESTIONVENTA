import hashlib


class Producto:
    def __init__(self, id_producto, nombre, precio, stock):
        self.__id = id_producto
        self.__nombre = nombre
        self.__precio = precio
        self.__descripcion = str()
        self.__categoria = str()
        self.__stock = stock

    def obtener_id(self):
        return self.__id
    
    def obtener_nombre(self):
        return self.__nombre
    
    def obtener_precio(self):
        return self.__precio
    
    def obtener_descripcion(self):
        return self.__descripcion
    
    def obtener_categoria(self):
        return self.__categoria
    
    def obtener_stock(self):
        return self.__stock
    
    def modificar_nombre(self, nombre):
        self.__nombre = nombre

    def modificar_precio(self, precio):
        self.__precio = precio

    def modificar_stock(self, stock):
        self.__stock = stock


class Venta:
    def __init__(self, id_venta, fecha, total, estado_pago, descripcion, cantidad, presupuesto):
        self.__id = id_venta
        self.__fecha = fecha
        self.__total = total
        self.__estado_pago = estado_pago
        self.__descripcion = descripcion
        self.__cantidad = cantidad 
        self.__presupuesto = presupuesto


    def obtener_id(self):
        return self.__id

    def obtener_fecha(self):
        return self.__fecha

    def obtener_total(self):
        return self.__total
    
    def obtener_estado_pago(self):
        return self.__estado_pago
    
    def obtener_descripcion(self):
        return self.__descripcion
    
    def obtener_cantidad(self):
        return self.__cantidad


    def obtener_presupuesto(self):
        return self.__presupuesto
    


class Gasto:
    def __init__(self, id_gasto, tipo, monto, fecha_gasto, presupuesto):
        self.__id = id_gasto
        self.__descripcion = str()
        self.__tipo = tipo
        self.__monto = monto
        self.__fecha = fecha_gasto
        self.__presupuesto = presupuesto

    def obtener_id(self):
        return self.__id
    
    def obtener_descripcion(self):
        return self.__descripcion
    
    def obtener_tipo(self):
        return self.__tipo
    
    def obtener_monto(self):
        return self.__monto
    
    def obtener_fecha(self):
        return self.__fecha
    
    def obtener_presupuesto(self):
        return self.__presupuesto
    
    def modificar_descripcion(self,descripcion):
        self.__descripcion = descripcion
    
    def modificar_tipo(self, tipo):
        self.__tipo = tipo

    def modificar_fecha(self, fecha_gasto):
        self.__fecha = fecha_gasto

    def modificar_monto(self, monto):
        self.__monto = monto
        

class Presupuesto(Venta, Gasto):
    def __init__(self, id_presupuesto, ventas, gastos, presupuesto_mensual, año, mes):
        self.__id = id_presupuesto
        self.__ventas = ventas
        self.__gastos = gastos
        self.__presupuesto = presupuesto_mensual
        self.__mes = mes

    def obtener_id(self):
        return self.__id

    def obtener_total_ventas(self):
        return self.__total_ventas

    def obtener_cantidad_ventas(self):
        return self.__cantidad_ventas

    def obtener_total_gastos(self):
        return self.__total_gastos

    def obtener_presupuesto_mensual(self):
        return self.__presupuesto

    def obtener_mes(self):
        return self.__mes
    
    def calculo_presupuesto_mensual(self):
        ventT= self.__ventas.obtener_total()
        gastM= self.__gastos.obtener_monto()
        presupuesto_mensual = ventT - gastM
        return presupuesto_mensual





class Item:
    def __init__(self, cantidad, id_venta, id_gasto):
        self.__cantidad = cantidad
        self.__id_venta = id_venta
        self.__id_gasto = id_gasto

    def obtener_cantidad(self):
        return self.__cantidad

    def obtener_id_venta(self):
        return self.__id_venta

    def obtener_id_gasto(self):
        return self.__id_gasto
        
class Usuario:
    def __init__(self, rut, nombre, contraseña,  rol, email, presupuesto):
        self.__rut = rut
        self.__nombre = nombre
        self.__contraseña = contraseña 
        self.__privilegios = str()
        self.__rol = rol
        self.__email = email
        self.__producto = []
        self.__venta = []
        self.__gasto = []
        self.__presupuesto = presupuesto

    def obtener_rut(self):
        return self.__rut

    def obtener_nombre(self):
        return self.__nombre
    
    def obtener_contraseña(self):
        return self.__contraseña
    
    def obtener_privilegio(self):
        return self.__privilegios
    
    def obtener_rol(self):
        return self.__rol
    
    def obtener_email(self):
        return self.__email
    
    def obtener_producto(self):
        return self.__producto
    
    def obtener_venta(self):
        return self.__venta
    
    def obtener_gasto(self):
        return self.__gasto
    
    def obtener_presupuesto(self):
        return self.__presupuesto
    
    def validar_clave(self, contraseña):
        enc = contraseña.encode()
        hash = hashlib.md5(enc).hexdigest()
        return self.__contraseña == hash

    def cambiar_clave(self, contraseña):
        enc = contraseña.encode()
        hash = hashlib.md5(enc).hexdigest()
        self.__contraseña = hash

    def cambiar_privilegio(self, privilegios):
        self.__privilegios = privilegios

    def cambiar_rol(self, rol):
        self.__rol = rol

    def cambiar_email(self, email):
        self.__email = email


    def agregar_venta(self, venta):
        self.__venta.append(venta)

    def agregar_gasto(self, gasto):
        self.__gasto.append(gasto)

    def agregar_producto(self, producto):
        self.__producto.append(producto)

    def quitar_venta(self, venta):
        self.__venta.remove(venta)
    
    def quitar_gasto(self, gasto):
        self.__gasto.remove(gasto)

    def quitar_producto(self, producto):
        self.__producto.remove(producto)
    
