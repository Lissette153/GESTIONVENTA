import tkinter as tk

#Importar modulos de tkinter
from tkinter import * 
from tkinter import ttk
from tkinter import messagebox

#PAGINAPRINCIPAL
def btn_click():
     print("¡Boton apretado con éxito!")

root = tk.Tk()
root.title("Página de inicio")
root.geometry("400x300")
title_label = tk.Label(root, text="¡Bienvenido a la Floreria La Blanco!", font=("Helvetica", 24), bg="lightpink")
title_label.place(relx=0.5, rely=1.5, anchor="center")
title_label.pack(pady=20)
textBox = Label(root, text="¡Donde dentro de esta aplicación podra ingresar sus datos manteniendo un control de su negocio!", font=("Helvetica", 15))
textBox.pack(pady=20)


def get_text():
    text = entry.get()
    print("Texto ingresado:", text)


#CORREO
form_frame = tk.Frame(root, padx=15, pady=15)
form_frame.pack()
text_correo = "Ingrese su correo"
entry = tk.Entry(form_frame)
entry.insert(0, text_correo)
entry.grid(row=0, column=1)

#CONTRASEÑA
form_frame = tk.Frame(root, padx=5, pady=5)
form_frame.pack()
text_contraseña = "Ingrese su contraseña"
entry = tk.Entry(form_frame)
entry.insert(0, text_contraseña)
entry.grid(row=0, column=1)


#BORRA EL TEXTO AL MOMENTO DE INGRESAR EL TEXTO
def on_click(event):
    if entry.get() == text_correo:
        entry.delete(0, tk.END)
        entry.config(fg='black')  

def on_click(event):
    if entry.get() == text_contraseña:
        entry.delete(0, tk.END)
        entry.config(fg='black')  # Cambiar el color del texto a negro



entry.bind("<FocusIn>", on_click)

# Botón de accion

form_frame = tk.Frame(root, padx=10, pady=10)
form_frame.pack()
button = tk.Button(form_frame, text="Iniciar sesión", command=get_text)
button.grid(row=1, columnspan=2)




root.mainloop()



#FORMULARIOUSUARIO
class FormularioUsuarios:
       
 def  Formulario():
   try:
        base= Tk()
        base.geometry("1200x300")
        base.title("Formulario de Ingreso de Usuarios")

        groupBox = LabelFrame(base, text=" Ingrese los datos del usuario", padx=5,pady=5)     
        groupBox.grid(row=0, column=0, padx=10, pady=10)
        #ID
        labelId = Label(groupBox, text="Rut: ",width=13, font=("arial,12")).grid(row=0, column=0)
        textBoxId = Entry(groupBox)
        textBoxId.grid(row=0, column=1)
        #NOMBRE
        labelNombre = Label(groupBox, text="Nombre: ",width=13, font=("arial,12")).grid(row=1, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=1, column=1)

        #EMAIL
        labelEmail = Label(groupBox, text="Email: ",width=13, font=("arial,12")).grid(row=2, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=2, column=1)

        #CONTRASEÑA 
        labelContraseña = Label(groupBox, text="Contraseña: ",width=13, font=("arial,12")).grid(row=3, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=3, column=1)

        #ROL
        labelRol = Label(groupBox, text="Rol: ",width=13, font=("arial,12")).grid(row=4, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=4, column=1)

        #PRIVILEGIOS
        labelPrivilegios= Label(groupBox, text="Privilegios: ",width=13, font=("arial,12")).grid(row=5, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=5, column=1)







        base.mainloop()

   except  ValueError as error:
            print("Error al mostrar la interfaz: {}".format(error))

 Formulario()

########
#BOTONES
#button1 = tk.Button(root, text="Ingresar usuario", width=10, command=btn_click)
#button1.pack(side="left", padx=10)
#button2 = tk.Button(root, text="Opción 1", width=10, command=btn_click)
#button2.pack(side="left", padx=10)
#button3 = tk.Button(root, text="Opción 2", width=10, command=btn_click)
#button3.pack(side="left", padx=10)
