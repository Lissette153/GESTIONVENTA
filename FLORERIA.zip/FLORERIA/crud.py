import mysql.connector
import hashlib
from modelo import Producto, Venta, Gasto, Presupuesto, Item, Usuario

import mysql.connector
import hashlib

class CrudUsuario:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def crear_usuario(self, rut, nombre, contraseña, rol, privilegios, email):
        hash_contraseña = hashlib.md5(contraseña.encode()).hexdigest()
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO usuario (rut, nombre, contraseña, rol, privilegios, email) VALUES (%s, %s, %s, %s, %s, %s)'
        val = (rut.obtener_rut(), nombre.obtener_nombre(), hash_contraseña, rol.obtener_rol(), privilegios.obtener_privilegio(), email.obtener_email())
        cursor.execute(sql, val)
        n_filas = cursor.rowcount
        self.conexion.commit()
        cursor.close()
        return n_filas > 0
    
    def obtener_usuarios(self):
        usuarios = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM usuario'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            user = Usuario(rut=row[0], nombre=row[1], rol=row[3], privilegios=row[4], email=row[5])
            usuarios.append(user)
        cursor.close()
        return usuarios
    
    def modificar_usuario(self, rut, usuario):
        cursor = self.conexion.cursor()
        sql = 'UPDATE usuario SET nombre = %s, rol = %s, privilegios = %s, email = %s WHERE rut = %s'
        val = (usuario.obtener_nombre(), usuario.obtener_rol(), usuario.obtener_privilegio(), usuario.obtener_email(), rut)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()
    
    def modificar_contraseña(self, rut, nueva_contraseña):
        hash_contraseña = hashlib.md5(nueva_contraseña.encode()).hexdigest()
        cursor = self.conexion.cursor()
        sql = 'UPDATE usuario SET contraseña = %s WHERE rut = %s'
        val = (hash_contraseña, rut)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()
    
    def eliminar_usuario(self, rut):
        cursor = self.conexion.cursor()
        try:
    
            sql = 'DELETE FROM usuario WHERE rut = %s'
            cursor.execute(sql, (rut,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el cliente: {e}')
        finally:
            cursor.close()



class CrudProducto:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def agregar_producto(self, nombre, precio, descripcion, categoria, stock):
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO producto (nombre, precio, descripcion, categoria, stock ) VALUES (%s, %s, %s, %s,%s)'
        val = (nombre, precio, descripcion, categoria, stock)
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
        
    
    def obtener_productos(self):
        productos = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM producto'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            producto = {
                'id_producto': row[0],
                'nombre': row[1],
                'precio': row[2],
                'descripcion': row[3],
                'categoria': row[4],
                'stock': row[5]
            }
            productos.append(producto)
        cursor.close()
        return productos
    
    def modificar_producto(self, id_producto, producto):
        cursor = self.conexion.cursor()
        sql = 'UPDATE producto SET nombre = %s, precio = %s, stock = %s WHERE id_producto = %s'
        val = (producto.obtener_nombre(), producto.obtener_precio(), producto.obtener_stock(), id_producto)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()
    
    def eliminar_producto(self, id_producto):
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM producto WHERE id_producto = %s'
            cursor.execute(sql, (id_producto,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el producto: {e}')
        finally:
            cursor.close()

    def obtener_inventario(self):
        productos = []
        cursor = self.conexion.cursor()
        sql = 'select id_producto, stock, nombre from producto'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            inv = Producto(id_producto=row[5], nombre=row[0], stock=row[4])
            productos.append(inv)
        return productos


class CrudVenta:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def agregar_venta(self, fecha, total, estado_pago, descripcion, cantidad):
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO venta (fecha, total, estado_pago, descripcion, cantidad ) VALUES (%s, %s, %s, %s,%s)'
        val = (fecha, total, estado_pago, descripcion, cantidad )
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
    
    def obtener_venta(self):
        ventas = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM venta'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            venta= {
                'id_venta': row[0],
                'fecha':row[1],
                'total':row[2],
                'estado_pago': row[3],
                'descripcion': row[4],
                'cantidad': row[5]
            }
            ventas.append(venta)
        cursor.close()
        return ventas
      
    def eliminar_venta(self, id_venta):
        cursor = self.conexion.cursor()
        try:
    
            sql = 'DELETE FROM venta WHERE id_venta = %s'
            cursor.execute(sql, (id_venta,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar la venta: {e}')
        finally:
            cursor.close()

    def calcular_monto_total_ventas(self, fecha):
        cursor = self.conexion.cursor(dictionary=True)
        sql = 'SELECT * FROM venta WHERE fecha = %s'
        cursor.execute(sql, (fecha,))
        ventas = cursor.fetchall()
        cursor.close()
        total_ventas = sum(venta['total'] for venta in ventas)
        if total_ventas > 0:
            return ventas, total_ventas
        else:
            raise Exception("Error: Cálculo no realizado o no hay ventas para esa fecha")
        

class CrudGasto:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def agregar_gasto(self, descripcion, tipo, monto, fecha_gasto):
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO gasto (descripcion, tipo, monto, fecha_gasto) VALUES (%s, %s, %s, %s)'
        val = (descripcion, tipo, monto, fecha_gasto)
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
    
    def obtener_gasto(self):
        gastos = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM gasto'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            gasto= {
                'id_gasto': row[5],
                'descripcion':row[0],
                'tipo':row[1],
                'monto': row[2],
                'fecha_gasto': row[3],
            }
            gastos.append(gasto)
        cursor.close()
        return gastos
    
    def modificar_gasto(self, id_gasto, gasto):
        cursor = self.conexion.cursor()
        sql = 'UPDATE gasto SET descripcion = %s, tipo = %s, fecha_gasto = %s, monto = %s WHERE id_gasto = %s'
        val = (gasto.obtener_descripcion(), gasto.obtener_tipo(), gasto.obtener_fecha(), gasto.obtener_montol(), id_gasto)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()


    def eliminar_gasto(self, id_gasto):
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM gasto WHERE id_gasto = %s'
            cursor.execute(sql, (id_gasto,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el gasto: {e}')
        finally:
            cursor.close()


    

class CrudPresupuesto:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )

    def generar_presupuesto_mensual(self, total_ventas, monto_gastos):
        presupuesto_mensual = total_ventas - monto_gastos
        return presupuesto_mensual
    
