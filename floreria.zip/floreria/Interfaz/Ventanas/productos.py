import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel
from logico.Producto.agregar_producto import VentanaAgregarProducto 
from logico.Producto.modificar_producto import VentanaModificarProducto

#DENTRO DE ESTA VENTANA DE PRODUCTOS NOS PERMITIRA AGREGAR PRODUCTO, MODIFICARLOS, ELIMINARLOS Y LO MAS IMPORTANTE, LISTARLOS.
#TAMBIÉN INCLUIMOS UNA INTERFAZ DE USUARIO BASTANTE AMIGABLE.

def mostrar_ventana_productos(self):
    """MOSTRAR_VENTANAS_PRODUCTOS NOS PERMITE LLEVAR A LA VENTANA DE PRODUCTOS(LA CUAL ES UNA CLASE)
    ARGS: 
        VentanaProductos(self)
    """
    ventana_productos = VentanaProductos(self)
    ventana_productos.grab_set()

def ventana_modificar_producto(self):
    """VENTANA_MODIFICAR_PRODUCTO NOS PERMITE LLEVAR A LA VENTANA DE MODIFICACIÓN DE PRODUCTOS (LA CUAL ES UNA CLASE)
    ARGS:
        VentanaModificarProducto(self)
    """
    ventana_productos = VentanaModificarProducto(self)
    ventana_productos.grab_set()

class VentanaProductos(tk.Toplevel):
    """
    DENTRO DE ESTA VENTANA DE PRODUCTOS NOS PERMITIRA AGREGAR PRODUCTOS, MODIFICARLOS, ELIMINARLOS Y LO MAS IMPORTANTE, LISTARLOS.
    TAMBIÉN INCLUIMOS UNA INTERFAZ DE USUARIO BASTANTE AMIGABLE.
    """
    def __init__(self, master=None):
        """Inicializamos la ventana de Productos con sus respectivos componentes.

        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Creamos un frame para contener la lista de productos.
        3. Creamos un Treeview, configuramos las columnas para sus respectivos atributos (id_producto, nombre, precio, descripcion, categoria y stock).
        5. Para permitirnos crear un producto, modificar y eliminar, diseñamos e incluimos botones que nos permitirá llevarnos a la clase de cada uno de estos.
        5. Mientras que, si el usuario desea volver hacia atrás (al panel de usuario local), generamos también un botón para volver.

        Args:
            master (tk.Tk, opcional): La ventana principal de la que se deriva esta ventana.
            tk.Frame: Nos permite definir la lista de productos con su self.
            self.pack: Nos permite indicar cuanto sería el pady.
            Crud_producto: Vinculación del crud de productos para incluir todas sus funciones necesarias para realizar el programa.
            Treeview: Permite mostrar los productos en forma de tabla.
            heading: Permite mostrar los productos y sus atributos en forma de tabla.
            button_agregar_producto: Botón para agregar productos(self.mostrar_ventana_agregar_producto).
            button_modificar_producto: Botón para modificar productos(self.mostrar_ventana_modificar).
            button_eliminar_producto: Botón para eliminar productos(self.mostrar_ventana_eliminar).
            button_volver: Botón para volver a la ventana principal(self.volver_al_inicio).
        """
        super().__init__(master)
        # Configura el fondo de la ventana y establece el título y el tamaño de la ventana.
        self.configure(background="#ffd7be")
        self.title("Productos")
        self.geometry("1500x500")

        self.crud_producto = CrudProducto()

        frame_lista_productos = tk.Frame(self)
        frame_lista_productos.pack(pady=10)

        self.lista_productos = ttk.Treeview(frame_lista_productos, columns=("id_producto", "nombre", "precio", "descripcion", "categoria", "stock"), show="headings")
        
        self.lista_productos.heading("id_producto", text="ID")
        self.lista_productos.heading("nombre", text="Nombre")
        self.lista_productos.heading("precio", text="Precio")
        self.lista_productos.heading("descripcion", text="Descripción")
        self.lista_productos.heading("categoria", text="Categoría")
        self.lista_productos.heading("stock", text="Stock")
        self.lista_productos.pack()

        boton_modificar = tk.Button(self, text="Modificar", command=self.modificar_producto)
        boton_modificar.pack(pady=10)

        boton_agregar = tk.Button(self, text="Agregar Producto", command=self.mostrar_ventana_agregar_producto)
        boton_agregar.pack(pady=10)

        boton_eliminar = tk.Button(self, text="Eliminar Producto", command=self.eliminar_producto)
        boton_eliminar.pack(pady=10)

        # 8. Llamamos al método para actualizar la lista de productos al inicializar la ventana.
        self.actualizar_lista_productos()


        boton_volver = tk.Button(self, text="Volver hacia atrás", command=self.volver_al_inicio)
        boton_volver.pack(pady=10)

    def volver_al_inicio(self):
        """
            Genera la variable de volver al inicio vinculada con el botón anteriormente mencionado (self.destroy()).

        Returns:
            Donde nos devuelve al panel de usuario local (DesignLocal)
        """
        self.destroy()  

    def actualizar_lista_productos(self):
        """
        1. Actualiza la lista de productos, eliminando los elementos actuales y añadiendo los productos actualizados desde la base de datos.
            self.lista_productos.delete(*self.lista_productos.get_children())
        2. Obtenemos el crud de productos para actualizar los productos
            self.crud_producto = CrudProducto()
        3. Actualizamos los productos.
            self.lista_productos.insert()
        Returns:
            :self.actualizar_lista_productos(): Actualizamos la lista de productos.
        """
        self.lista_productos.delete(*self.lista_productos.get_children())
        productos = self.crud_producto.obtener_productos()
        for producto in productos:
            self.lista_productos.insert("", tk.END, values=(producto.obtener_id(), producto.obtener_nombre(), producto.obtener_precio(), producto.obtener_descripcion(), producto.obtener_categoria(), producto.obtener_stock()))

    def modificar_producto(self):
        """
        Generamos un método para modificar un producto seleccionado. Abre la ventana de modificación si un producto está seleccionado.
        Args:   
            seleccion = self.lista_productos.selection(): Nos permite seleccionar dentro de la lista un producto.
            id_producto: self.lista_productos.item(): De acuerdo a la selección se vincula con la id_producto.
            self.crud_producto.buscar_producto(id_producto): Nos permite acceder al crud de producto y llamar al buscar_producto con su id previa.
            VentanaModificarProducto: Hace un llamado a la Ventana de modificación de producto.
        Raises:
            Exception: Si ocurre un error al buscar el producto o no lo encuentra.
        """
        seleccion = self.lista_productos.selection()
        if seleccion:
            id_producto = self.lista_productos.item(seleccion[0], "values")[0]
            producto = self.crud_producto.buscar_producto(id_producto)
            if producto:
                ventana_modificar_producto = VentanaModificarProducto(self, id_producto, producto)
                ventana_modificar_producto.grab_set()
            else:
                messagebox.showerror("Error", "Producto no encontrado.")
        else:
            messagebox.showwarning("Error", "Seleccione un producto para modificar.")
    
    def mostrar_ventana_agregar_producto(self):
        """
        Crea un método que nos permite llevar a la ventana de agregación de productos (variable y clase: VentanaAgregarProducto)
        Raises:
            Exception: Si ocurre un error al abrir la ventana de agregar producto.
        """
        ventana_agregar_producto = VentanaAgregarProducto(self)
        ventana_agregar_producto.grab_set() 

    def eliminar_producto(self):
        """
        Crea un método para eliminar un producto seleccionado, la cual pide confirmación antes de eliminar y actualiza la lista de productos.
        Args:
            seleccion = self.lista_productos.selection(): Nos permite seleccionar dentro de la lista un producto.
            id_producto: self.lista_productos.item(): De acuerdo a la selección se vincula con la id_producto.
            messagebox: Nos permite confirmar la eliminación del producto en caso de no estar seguros.
            self.crud_producto.eliminar_producto(id_producto): Nos permite acceder al crud de producto y eliminarlo según el producto que seleccionamos
            ( a través de id_producto )
            self.actualizar_lista_productos: Nos permite actualizar la lista de productos.
        Raises:
            Exception: Si ocurre un error al eliminar el producto.
        """
        seleccion = self.lista_productos.selection()
        if seleccion:
            id_producto = self.lista_productos.item(seleccion[0], "values")[0]
            if messagebox.askyesno("Confirmar Eliminación", "¿Está seguro de que desea eliminar este producto?"):
                self.crud_producto.eliminar_producto(id_producto)
                self.actualizar_lista_productos()
        else:
            messagebox.showwarning("Error", "Seleccione un producto para eliminar.")
