import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel
from logico.Venta.agregar_venta import VentanaAgregarVenta
from logico.Venta.informe_venta import VentanaInformeVentas

#DENTRO DE ESTA VENTANA DE VENTAS NOS PERMITIRA AGREGAR VENTAS, ELIMINAR Y LO MAS IMPORTANTE, LISTARLOS. TAMBIÉN INCLUYE UN INFORME DE VENTAS
#TAMBIÉN INCLUIMOS UNA INTERFAZ DE USUARIO BASTANTE AMIGABLE.


def mostrar_ventana_ventas(self):
    """MOSTRAR_VENTANAS_VENTAS NOS PERMITE LLEVAR A LA VENTANA DE VENTAS(LA CUAL ES UNA CLASE)
    ARGS: 
        VentanaVentas(self)
    """
    ventana_ventas = VentanaVentas(self)
    ventana_ventas.grab_set()

class VentanaVentas(tk.Toplevel):
    """
    DENTRO DE ESTA VENTANA DE VENTAS NOS PERMITIRA AGREGAR VENTAS, ELIMINARLAS, GENERAR INFORMES Y LO MAS IMPORTANTE, LISTARLAS.
    TAMBIÉN INCLUIMOS UNA INTERFAZ DE USUARIO BASTANTE AMIGABLE.
    """
    def __init__(self, master=None):
        """
        Inicializamos la ventana de Ventas con sus respectivos componentes.

        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Creamos un frame para contener la lista de ventas.
        3. Creamos un Treeview, configuramos las columnas para sus respectivos atributos (id_venta, fecha, total, estado_pago, descripción, cantidad).
        5. Para permitirnos crear una venta, eliminar y generar un informe de ventas, diseñamos e incluimos botones que nos permitirá llevarnos a la clase de cada uno de estos.
        5. Mientras que, si el usuario desea volver hacia atrás (al panel de usuario local), generamos también un botón para volver.

        Args:
            master (tk.Tk, opcional): La ventana principal de la que se deriva esta ventana.
            Crud_Venta: Vinculación del crud de productos para incluir todas sus funciones necesarias para realizar el programa.
            tk.Frame = Nos permite asignar la lista de ventas y su self.
            self.pack = Nos permite asignar cuanto será el pady de la lista de ventas.
            Treeview: Permite mostrar las Ventas en forma de tabla.
            heading: Permite mostrar las ventas y sus atributos en forma de tabla.
            button_agregar_venta: Botón para agregar productos(self.mostrar_ventana_agregar_venta). INCLUYE un pady
            button_eliminar_venta: Botón para eliminar productos(self.mostrar_ventana_eliminar). INCLUYE un pady
            button_informe_venta: Botón para generar un informe de ventas(self.mostrar_ventana_informe_ventas). INCLUYE un pady
            button_volver: Botón para volver a la ventana principal(self.volver_al_inicio). INCLUYE un pady
        """
        super().__init__(master)
        # Configura el fondo de la ventana y establece el título y el tamaño de la ventana.
        self.title("Ventas")
        self.configure(background="#ffd7be")
        self.geometry("1500x500")

        self.crud_venta = CrudVenta()


        frame_lista_ventas = tk.Frame(self)
        frame_lista_ventas.pack(pady=10)

        self.lista_ventas = ttk.Treeview(frame_lista_ventas, columns=("id_venta", "fecha", "total", "estado_pago", "descripcion", "cantidad"), show="headings")
        
        self.lista_ventas.heading("id_venta", text="ID")
        self.lista_ventas.heading("fecha", text="Fecha")
        self.lista_ventas.heading("total", text="Total")
        self.lista_ventas.heading("estado_pago", text="Estado de pago")
        self.lista_ventas.heading("descripcion", text="Descripción")
        self.lista_ventas.heading("cantidad", text="Cantidad")
        self.lista_ventas.pack()

        boton_agregar = tk.Button(self, text="Agregar Venta", command=self.mostrar_ventana_agregar_venta)
        boton_agregar.pack(pady=10)


        boton_eliminar = tk.Button(self, text="Eliminar Venta", command=self.eliminar_venta)
        boton_eliminar.pack(pady=10)

        boton_informe = tk.Button(self, text="Informe de Ventas", command=self.mostrar_ventana_informe_ventas)
        boton_informe.pack(pady=10)

        boton_volver = tk.Button(self, text="Volver hacia atrás", command=self.volver_al_inicio)
        boton_volver.pack(pady=10)

        self.actualizar_lista_ventas()

    def eliminar_venta(self):
        """
        Crea un método para eliminar una venta seleccionada, la cual pide confirmación antes de eliminar y actualiza la lista de ventas.
        Args:
            seleccion = self.lista_ventas.selection(): Nos permite seleccionar dentro de la lista una venta
            id_producto: self.lista_ventas.item(): De acuerdo a la selección se vincula con la id_venta.
            messagebox: Nos permite confirmar la eliminación de la venta en caso de no estar seguros.
            self.crud_producto.eliminar_venta(id_venta): Nos permite acceder al crud de venta y eliminarlo según la venta que seleccionamos.
            ( a través de id_venta)
            self.actualizar_lista_ventas: Nos permite actualizar la lista de ventas.
        Raises:
            Exception: Si ocurre un error al eliminar la venta.
        """
        seleccion = self.lista_ventas.selection()
        if seleccion:
            id_venta = self.lista_ventas.item(seleccion[0], "values")[0]
            if messagebox.askyesno("Confirmar Eliminación", "¿Está seguro de que desea eliminar esta venta?"):
                self.crud_venta.eliminar_venta(id_venta)
                self.actualizar_lista_ventas()
        else:
            messagebox.showwarning("Error", "Seleccione una venta para eliminar.")

    def volver_al_inicio(self):
        """
          Genera la variable de volver al inicio vinculada con el botón anteriormente mencionado (self.destroy()).

        Returns:
            Donde nos devuelve al panel de usuario local (DesignLocal)
        """
        self.destroy()  

    def actualizar_lista_ventas(self):
        """
        1. Actualiza la lista de ventas, eliminando los elementos actuales y añadiendo las ventas actualizadas desde la base de datos.
            self.lista_ventas.delete(*self.lista_ventas.get_children())
        2. Obtenemos el crud de ventas para actualizar las ventas
            self.crud_venta = CrudVenta()
        3. Utilizamos una condición para declarar el estado de pago como "Pagado" y "No Pagado" con if.
            obtener_estado_pago == "Pagado", obtener_estado_pago == "No Pagado".
        3. Actualizamos las ventas.
            self.lista_ventas.insert()

        Returns:
            :self.actualizar_lista_ventas(): Actualizamos las ventas.
        """
        self.lista_ventas.delete(*self.lista_ventas.get_children())
        ventas = self.crud_venta.obtener_venta()
        for venta in ventas:
            tags = ()
            if venta.obtener_estado_pago() == "Pagado":
                tags = ("pagado",)
            elif venta.obtener_estado_pago() == "No Pagado":
                tags = ("no_pagado",)
            else:
                tags = ("estado_no_declarado",)
            self.lista_ventas.insert("", tk.END, values=(venta.obtener_id(), venta.obtener_fecha(), venta.obtener_total(), venta.obtener_estado_pago(), venta.obtener_descripcion(), venta.obtener_cantidad()), tags=tags)

    def mostrar_ventana_agregar_venta(self):
        """
        Crea un método que nos permite llevar a la ventana de agregación de ventas(variable y clase: VentanaAgregarVenta)
        Raises:
            Exception: Si ocurre un error al abrir la ventana de agregar venta
        """
        ventana_agregar_venta = VentanaAgregarVenta(self)
        ventana_agregar_venta.grab_set()

    def mostrar_ventana_informe_ventas(self):
        """
        Crea un método que nos permite mostrar la ventana de informe de ventas y generar el calculo de este. (Variable y clase: VentanaInformeVenta).

        Raises:
            Exception: Si ocurre un error al abrir la ventana de informe de ventas.
        """
        ventana_informe_ventas = VentanaInformeVentas(self)
        ventana_informe_ventas.grab_set()
