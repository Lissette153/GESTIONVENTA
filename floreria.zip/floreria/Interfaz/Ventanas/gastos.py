__package__ = 'formularios'

import tkinter as mainloop
import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel
from logico.Gasto.agregar_gasto import VentanaAgregarGasto


def mostrar_ventanas_gasto(self):
    """MOSTRAR_VENTANAS_GASTO NOS PERMITE LLEVAR A LA VENTANA DE GASTO(LA CUAL ES UNA CLASE)
    ARGS: 
        VentanaGasto(self)
    """
    ventana_gastos = VentanaGasto(self)
    ventana_gastos.grab_set()

class VentanaGasto(tk.Toplevel):
    """
    DENTRO DE ESTA VENTANA DE GASTOS NOS PERMITIRA AGREGAR GASTOS Y LISTARLOS.
    TAMBIÉN INCLUIMOS UNA INTERFAZ DE USUARIO BASTANTE AMIGABLE.
    """

    def __init__(self, master=None):
        """
        Inicializamos la ventana de Gastos con sus respectivos componentes.

        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Generamos una variable llamada frame_lista_gasto.
        3. Creamos un Treeview, configuramos las columnas para ID, descripción, tipo, monto y fecha del gasto.
        4. Para permitirnos crear un gasto, diseñamos e incluimos un botón que permitirá llevarnos a la clase de agregar gasto.
        5. Mientras que, si el usuario desea volver hacia atrás (al panel de usuario local), generamos también un botón para volver.

        Args:
            master (tk.Tk, opcional): La ventana principal de la que se deriva esta ventana.
            tk.Frame = Nos permite definir la lista de gastos con su self.
            self.pack: Nos permite indicar cuanto será el pady.
            Crud_gasto: Vinculación del crud de gasto para incluir todas sus funciones necesarias para realizar el programa.
            frame_lista_gasto:frame con lista.
            Treeview: Permite mostrar los gastos en forma de tabla.
            heading: Permite mostrar los gastos y sus atributos en forma de tabla.
            button_agregar_gasto: Botón para agregar gastos(self.mostrar_ventana_agregar_gasto).
            button_volver: Botón para volver a la ventana principal(self.volver_al_inicio)
        """
        super().__init__(master)
        self.title("Gastos")
        self.configure(background="#ffd7be")
        self.geometry("1500x500")
        
        self.crud_gasto = CrudGasto()

        frame_lista_gasto = tk.Frame(self)
        frame_lista_gasto.pack(pady=10)

 
        self.lista_gasto = ttk.Treeview(frame_lista_gasto, columns=("id_gasto", "descripcion", "tipo", "monto", "fecha_gasto"), show="headings")
        self.lista_gasto.heading("id_gasto", text="ID")
        self.lista_gasto.heading("descripcion", text="Descripción")
        self.lista_gasto.heading("tipo", text="Tipo")
        self.lista_gasto.heading("monto", text="Monto")
        self.lista_gasto.heading("fecha_gasto", text="Fecha del gasto")
        self.lista_gasto.pack()

        boton_agregar = tk.Button(self, text="Agregar gasto", command=self.mostrar_ventana_agregar_gasto)
        boton_agregar.pack(pady=10)
        
        boton_volver = tk.Button(self, text="Volver hacia atrás", command=self.volver_al_inicio)
        boton_volver.pack(pady=10)


        self.actualizar_lista_gasto()

    def mostrar_ventana_agregar_gasto(self):
        """
        Crea una función que nos permite llevar a la ventana de agregación de gasto (variable y clase: VentanaAgregarGasto).
        Raises:
            Exception: Si ocurre un error al abrir la ventana de agregar gasto.
        """
        ventana_agregar_gasto = VentanaAgregarGasto(self)
        ventana_agregar_gasto.grab_set()

    def actualizar_lista_gasto(self):
        """
       1. Actualiza la lista de gastos, eliminando los elementos actuales y añadiendo los gastos actualizados desde la base de datos.
            self.lista_gasto.delete(*self.lista_gasto.get_children())
       2. Obtenemos el crud de gastos para actualizar los gastos.
            self.crud_gasto = CrudGasto()
       3. Actualizamos los gastos.
            self.lista_gasto.insert()
        Returns:
            :self.actualizar_lista_gasto(): Actualizamos la lista de gastos.
        """
        self.lista_gasto.delete(*self.lista_gasto.get_children())
        gastos = self.crud_gasto.obtener_gasto()
        for gasto in gastos:
            self.lista_gasto.insert("", tk.END, values=(gasto.obtener_id(), gasto.obtener_descripcion(), gasto.obtener_tipo(), gasto.obtener_monto(), gasto.obtener_fecha()))

    def volver_al_inicio(self):
        """
        Genera la variable de volver al inicio vinculada con el botón anteriormente mencionado (self.destroy()).

        Returns:
            Donde nos devuelve al panel de usuario local (DesignLocal)
        """
        self.destroy()
