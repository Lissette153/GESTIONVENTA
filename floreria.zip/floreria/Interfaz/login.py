__package__ = 'Interfaz'

import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from Presentacion.design.form_designL import DesignLocal
from Presentacion.design.form_design import Design


#--- INICIO LOGIN -------

class Login(tk.Tk):
    """
    -DENTRO DE LA CLASE LOGIN PERMITIREMOS ACCEDER AL PANEL DE ADMINISTRADOR (BOTÓNES) DONDE PODREMOS CREAR USUARIOS, 
    MODIFICAR, ELIMINAR Y LISTAR.

    -MIENTRAS QUE DENTRO DEL PLANEL DE LOCAL PODREMOS CREAR, MODIFICAR, ELIMINAR Y LISTAR PRODUCTOS Y GASTOS, PARA VENTAS IGUAL 
    SOLO QUE EN VEZ DE MODIFICAR SOLO ELIMINAR E GENERAR UN INFORME DE VENTAS.
    """

    def __init__(self):
        """
        Inicializamos la ventana de Login con sus respectivos componentes(titulo, geometria).
        Args:
            self: Objeto de la clase Login.
            self.config: Panel de configuración.
            self.botones: Panel de botones.
        """     
        super().__init__()
        self.title("Floreria La Blanco")
        w, h = 1024, 250
        self.geometry(f"{w}x{h}")
        self.config()
        self.botones()

    def config(self):
        """
        Configuramos  el frame de login con sus respectivos componentes visuales.
        
        1.Primero configuramos el frame de Login.
        2. GENERAMOS UN TITULO ("¡Bienvenido a Floreria La Blanco!")
        3. GENERAMOS UN PARRAFO (¡Donde dentro de esta aplicación podra ingresar sus datos manteniendo un control de su negocio!)
        4. GENERAMOS UN TITULO DE OPCIONES ("Iniciar según las opciones elegidas: ADMIN O LOCAL")

        Args:   
            self (self): Objeto de la clase Login.
            tk.Frame: Frame de navbar y login.
            font_awesoma: Declaración de la letra que se utilizara en el frame.
            LabelTitle: tk.Label: Establecemos un label que nos permite ingresar el titulo y también incluirlo en el navbar, con su respectivo color.
            LabelText: tk.Label: Establecemos un label que nos permite ingresar el parrafo con su respectivo color.
        """
        self.navbar_frame = tk.Frame(self, height=500)
        self.navbar_frame.pack(side=tk.TOP, fill='both')

        
        font_awesome = font.Font(family='FontAwesome', size=12)
        self.LabelTitle = tk.Label(self.navbar_frame, text="¡Bienvenido a Floreria La Blanco!", bg="#e4717a", fg="black")
        self.LabelTitle.config(font=("Arial", 35), pady=10, width=1000)
        self.LabelTitle.pack(side=tk.TOP)

        self.LabelText = tk.Label(text='¡Donde dentro de esta aplicación podra ingresar sus datos manteniendo un control de su negocio!', bg="#ffc0a9")
        self.LabelText.config(font=("Arial", 12), pady=10, width=100000)
        self.LabelText.pack(side=tk.TOP)

        self.LabelOpciones = tk.Label(text="Iniciar según las opciones elegidas: ADMIN O LOCAL", bg="#ffc0a9")
        self.LabelOpciones.config(font=("Arial", 15), pady=10, width=100)
        self.LabelOpciones.pack(side=tk.TOP)

    def botones(self):
        """
        Configuramos los botones que vienen dentro del frame de botones con sus respectivos comandos para abrir los paneles de control.

        ARGS:
            1. GENERAMOS EL FRAME DE BOTÓN: button_frame.tk.Frame (Con su respectivo color)
            2. Agregamos los botones dentro del frame donde incluimos un comando (metodo) para abrir cada panel de control (local y administrador):
                1. Boton de local: tk.Button (Con su respectivo color, command= self.abrir_local)
                2. Boton de administrador: tk.Button (Con su respectivo color, command= self.abrir_admin)

        """
        self.button_frame = tk.Frame(self, bg="#ffc0a9")
        self.button_frame.pack(side=tk.TOP, fill="both", pady=0)

    
        self.buttonLocal = tk.Button(self.button_frame, text="Ingresar a las opciones de local", command=self.abrir_local, bg="indian red")
        self.buttonLocal.pack(side=tk.TOP, pady=10)

        self.buttonAdmin = tk.Button(self.button_frame, text="Ingresar a las opciones de administrador", command=self.abrir_admin, bg="indian red")
        self.buttonAdmin.pack(side=tk.TOP, pady=10)

    def abrir_local(self):
        """
        Generamos el método para abrir la ventana del panel de control  de usuario local
        Args:
            DesignLocal(): Ventana de panel de usuario local.
        """
        local = DesignLocal()
        local.mainloop()

    def abrir_admin(self):
        """
        Generamos el método para abrir la ventana del panel de control de  usuario administrador
        Args: 
            Design(): Ventana de panel de usuario administrador.
        """
        admin = Design()
        admin.mainloop()
