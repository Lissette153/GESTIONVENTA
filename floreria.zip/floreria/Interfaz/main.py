
import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from Interfaz.login import Login



import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox


if __name__ == "__main__":
    """
    EL METODO QUE SE APLICA PARA EJECUTAR LA APLICACIÓN ES UN LLAMADO A UN MAIN (PANTALLA PRINCIPAL)  Y AL MISMO TIEMPO 
    LLAMA A  LA PAGINA LOGIN QUE PERMITE ACCEDER A ESTA MISMA.
    ARGS:
        Login(): Ventana de Login.
    """
    app = Login()
    app.mainloop()