
def centrar_ventana(ventana,aplicacion_ancho,aplicacion_largo):
    """
    Dentro de esta función centramos la ventana con las medidas de la aplicación (largo y ancho), establecemos el tamaño de la ventana
    y devolvemos la geometria.

    Args:
        ventana: Función que nos permite asignar un parametro de ventana.
        pantalla_ancho: Le asignamos la ventana y un winfo_screenwidth, luego lo divimos en 2 y lo restamos con aplicación_ancho
        pantalla_largo: Le asignamos la ventana y un winfo_screenheight, luego lo divimos en 2 y lo restamos con aplicación_largo
        winfo_screenwidth: Obtenemos las dimensiones de la pantalla en píxeles (en este caso el ancho).
        winfo_screenheight: Obtenemos las dimensiones de la pantalla en píxeles (en este caso el largo).
        aplicacion_ancho (int): Asignación del ancho de la aplicación.
        aplicacion_largo (int): Asignación del largo de la aplicación.

    Returns:
        _type_: _description_
    """
    pantall_ancho = ventana.winfo_screenwidth()
    pantall_largo = ventana.winfo_screenheight()
    x = int((pantall_ancho/2) - (aplicacion_ancho/2))
    y = int((pantall_largo/2) - (aplicacion_largo/2))
    return ventana.geometry(f"{aplicacion_ancho}x{aplicacion_largo}+{x}+{y}")