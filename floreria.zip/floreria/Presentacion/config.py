
"""
Establecemos los colores de cada menu, barra, cuerpo y cursor para luego utilizarlos en el panel de control de usuario local y administrador.
"""

COLOR_BARRA_SUPERIOR = "#1f2329"
COLOR_MENU_LATERAL = "#2a3138"
COLOR_CUERPO_PRINCIPAL= "#f1faff"
COLOR_MENU_CURSOR =  "#2f88c5"
COLOR_CURSOR_ENCIMA =  "#2f88c5"