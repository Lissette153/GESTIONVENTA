__package__ = 'Presentacion/design'
import tkinter as tk
from tkinter import ttk
from tkinter import font
from Presentacion.config import (
    COLOR_BARRA_SUPERIOR, 
    COLOR_CUERPO_PRINCIPAL, 
    COLOR_MENU_CURSOR, 
    COLOR_MENU_LATERAL, 
    COLOR_CURSOR_ENCIMA
)
import Presentacion.util.util_ventanas as util_ventana
from Interfaz.Ventanas.ventas import * 
from Interfaz.Ventanas.productos import *
from Interfaz.Ventanas.gastos import *
from BD.crud import *
from BD.modelo import *

#FRAME DE PANEL DE CONTROL DE USUARIO LOCAL


class DesignLocal(tk.Tk):
    """""
     Clase para la ventana de panel de control de usuario local, que permite al usuario revisar el panel donde viene Gestión de Ventas, 
     Gestión de Productos y Gestión de Gastos. Además, permite al usuario volver a la pantalla principal.
    """
    def __init__(self):
        """""
        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. DEFINIMOS CADA METODO CON SU SELF PARA LUEGO UTILIZARLOS EN EL PANEL (VENTANA, PANELES, BARRA_SUPERIOR, MENU_LATERAL Y CUERPO)
        Args:
            self.config_window: Nos permite configurar la ventana del panel.
            self.paneles: Nos permite configurar los paneles.
            sel.controles_barra_superior: Administramos la barra superior (color, tamaño y texto)
            self.controles_menu_lateral: Administramos la barra lateral (Asignamos un menu donde se podra ingresar dentro de los botones)
            self.controles_cuerpo: Administramos el cuerpo de la ventana.
        """
        super().__init__()
        self.config_window()
        self.paneles()
        self.controles_barra_superior()
        self.controles_menu_lateral()
        self.controles_cuerpo()

    def config_window(self):
        """ 
        Configuramos la ventana principal con un titulo, tamaño(1024,600) y centramos la ventana
        """
        self.title('Panel de Usuario Local')
        w, h = 1024,600
        util_ventana.centrar_ventana(self, w,h)
    
    def paneles(self):
        """
        Configuramos los paneles de la ventana y sus colores que tendran. (los cuales ya estan definidos en otro frame)
           
        Args:
            self.barra_superior: Nos permite configurar la barra superior.
            tk.Frame: Configuramos el background y el height(50)
            self.pack: Configuramos donde estara ubicado la barra(TOP) y su fill(both)
            ------------------------------------------------------------------
            self.menu_lateral: Nos permite configurar la barra lateral.
            tk.Frame: Configuramos el background y el width(150)
            self.pack: Configuramos donde estara ubicado la barra(LEFT), su fill(both) y si se expande(FALSE)
            ------------------------------------------------------------------
            self.cuerpo: Nos permite configurar el cuerpo de la ventana.
            tk.Frame: Configuramos el background y el width(150)
            self.pack: Configuramos donde estara ubicado la barra(RIGHT), su fill(both) y si se expande(TRUE)
        """

        self.barra_superior = tk.Frame(self, bg=COLOR_BARRA_SUPERIOR, height=50)
        self.barra_superior.pack(side=tk.TOP, fill='both')
        
        self.menu_lateral = tk.Frame(self, bg=COLOR_MENU_LATERAL, width=150)
        self.menu_lateral.pack(side=tk.LEFT, fill='both', expand=False)

        self.cuerpo_principal = tk.Frame(self, bg=COLOR_CUERPO_PRINCIPAL, width=150)
        self.cuerpo_principal.pack(side=tk.RIGHT, fill='both', expand=True)

    def controles_barra_superior(self):
        """
        Configuramos los controles de la barra superior y la fuente de la letra
        Args: 
            FontAwesome: Asignamos esta fuente de letra y su tamaño(12).
            self.labelTitulo: Configuramos el titulo
            tk.Label: Configuramos la barra_superior y su texto.
            self.config: Configuramos el color de la letra, background(que ya esta asignado en config), pady(10) y width(156)
            self.pack: Configuramos donde estara ubicado la barra(LEFT)
            ----------------------------------------------------------
            self.buttonMenuLateral: Configuramos el botón.
            tk.Button: Configuramos que el boton despliegue el menu lateral (text, font, comando que lleva al panel lateral, color de background y comando)
            self.pack: Asignamos la configuración de la ubicación(LEFT)
            ---------------------------------------------------------
            self.LabelCorreo: Configuramos el correo.
            tk.Label: Configuramos para la barra_superior y su texto.
            self.config: Configuramos el color de la letra, background(que ya esta asignado en config), pady(10) y width(20)
            self.pack: Configuramos donde estara ubicado la barra(RIGHT)
        """
        font_awesome = font.Font(family='FontAwesome', size=12)
       
        self.Labeltitulo = tk.Label(self.barra_superior, text="Panel de Usuario Local Floreria La blanco")
        self.Labeltitulo.config(fg="#fff", font=("Roboto", 15), bg=COLOR_BARRA_SUPERIOR, pady=10, width=156)
        self.Labeltitulo.pack(side=tk.LEFT)

        self.buttonMenuLateral = tk.Button(self.barra_superior, text="\uf0c9", font=font_awesome, command=self.toggle_panel, bd=0, bg=COLOR_BARRA_SUPERIOR, fg="white")
        self.buttonMenuLateral.pack(side=tk.LEFT)

        self.labelTitulo = tk.Label(self.barra_superior, text="joisyda0512@gmail.com")
        self.labelTitulo.config(fg="#fff", font=("Roboto", 10), bg=COLOR_BARRA_SUPERIOR, padx=10, width=20)
        self.labelTitulo.pack(side=tk.RIGHT)

    def controles_menu_lateral(self):
        """
        Configuramos los controles del menu lateral.
           1.Establecemos un ancho de 20 y un alto  de 2 e Incorporamos la fuente de letra "FontAwesome"
           2. Incorporamos la etiqueta del perfil (La cual solo esta de decoración ya que no realiza nada)
           3. Incorporamos los botones del menú lateral
           4. Definimos lo que mostrara cada botón para que el usuario tenga una vista previa de estos
           5. Configuramos cada botón del menú con self.
        Args:
            self.buttonPerfil: Configuramos el botón que permitirá también estar en el menu lateral (incluye un bg)
            buttonProfile: Asignamos un boton de Perfil.
            ------------------------------------------------------------------
            self.buttonP: Configuramos el botón que permitirá crear y gestionar productos.
            buttonP: Asignamos un botón de Productos.
            ------------------------------------------------------------------
            self.buttonV: Configuramos el botón que permitirá crear y gestionar ventas.
            buttonV: Asignamos un botón de Ventas.
            ------------------------------------------------------------------
            self.buttonG: Configuramos el botón que permitirá  crear y gestionar gastos.
            buttonG: Asignamos un botón de Gastos.
            ------------------------------------------------------------------
            self.buttonP: Configuramos el botón que permitirá crear y gestionar el presupuesto.
            buttonP: Asignamos un botón de Presupuesto.
            ------------------------------------------------------------------
            self.volver_button: Configuramos el botón que permitirá volver hacia atras.
            buttons_info: permitirá mostrar un identificador para cada boton y asigna cada self. (profile, Productos, Ventas, Gastos, 
            Presupuesto, Log out)
            self.configurar_boton_menu: Asigna los botones, texto, icon, font, ancho y alto.
        """
        ancho_menu = 20
        alto_menu = 2
        font_awesome = font.Font(family='FontAwesome', size=15)
         
        self.labelPerfil = tk.Label(
            self.menu_lateral,  bg=COLOR_MENU_LATERAL)
        self.labelPerfil.pack(side=tk.TOP, pady=10)


        self.buttonProfile = tk.Button(self.menu_lateral)
        self.buttonP = tk.Button(self.menu_lateral, command= self.panel_producto)  
        self.buttonV = tk.Button(self.menu_lateral, command= self.panel_venta)
        self.buttonG = tk.Button(self.menu_lateral, command= self.panel_gasto)
        self.buttonPres= tk.Button(self.menu_lateral, command= self.panel_presupuesto) 
        self.buttonLogOut = tk.Button(self.menu_lateral, command=self.volver_al_inicio)


        buttons_info = [
            ("Profile", "\uf007", self.buttonProfile),
            ("Productos", "\uf02c", self.buttonP),
            ("Ventas", "\uf09d", self.buttonV),
            ("Gastos", "\uf0f0", self.buttonG),
            ("Presupuesto", "\uf0f0", self.buttonPres),
            ("Log Out", "\uf013", self.buttonLogOut)
        ]

        for text, icon, button in buttons_info:
            self.configurar_boton_menu(button, text, icon, font_awesome, ancho_menu, alto_menu)
            button.pack(side=tk.TOP)

    def panel_producto(self):
        """
        Abrimos la ventana del gestor de Productos
        Args: 
            VentanaProductos(): 
        """
        VentanaProductos()

    def panel_venta(self):
        """
        Abrimos la ventana del gestor de Ventas
        Args: 
            VentanaVentas(): 
        """
        VentanaVentas()

    def panel_gasto(self):
        """
        Abrimos la ventana del gestor de Gasto
        Args: 
            VentanaGasto(): 
        """
        VentanaGasto()
    
    def panel_presupuesto(self):
        """
        En este caso, como el panel de presupuesto no esta desarrollado asignamos un pass.
        Return:
            pass
        """
        pass

    def controles_cuerpo(self):
        """
        Configuramos el cuerpo principal con su background(que ya esta asignado en config) y cuantas longitud tiene.
        Args:
            tk.Label: Nos permite asignar el cuerpo principal y bg.
            place: Asignamos x, y, relwidth(1) y relheight(1)
        """
        label = tk.Label(self.cuerpo_principal, bg= COLOR_CUERPO_PRINCIPAL)
        label.place(x=0, y=0, relwidth=1, relheight=1)
    
    def configurar_boton_menu(self, button, text,icon, font_awesome, ancho_menu, alto_menu):
        """"
        Configuramos los botones del menú lateral con su background, width y font.
        Args:
            bg: Asignamos el background(que esta en config ya asignado)
            fg: Asignamos el color de la letra.
            text: Vinculamos(Configuración) del texto que se mostrara.
            icon: Asignamos un icono(que en realidad no tiene)
            font_awesome: Asignamos la fuente de letra.
            ancho_menu: Asignamos el ancho del menu
            alto_menu: Asignamos el alto del menu.
            pack: Asignamos la posición del boton.
            bind_hover_events: Asignamos los eventos con el botón.
        """
        button.config(text=f" {icon}  {text}", anchor="w", font=font_awesome,
                      bd=0, bg=COLOR_MENU_LATERAL, fg="white", width=ancho_menu, height=alto_menu)
        button.pack(side=tk.TOP)
        self.bind_hover_events(button)
    
    def bind_hover_events(self, button):
        """
        Asociamos los eventos de hover a los botones con lamba y self.
        Args:
            button: asignamos bind, enter, lambda event y on_enter.
            button: asignamos bind, leave, lambda event y on_leave.
            Enter: Se activa cuando el cursor del mouse entra en el área del widget.
            Leave: Se activa cuando el cursor del mouse sale del área del widget.
            lamba event: La utilizamos para manejar eventos de una manera más flexible, donde nos permite definir rápidamente funciones
            de manejo de eventos
        """
        button.bind("<Enter>", lambda event: self.on_enter(event, button))
        button.bind("<Leave>", lambda event: self.on_leave(event, button))

    def on_enter(self, event, button):
        """
        Cambiamos el estilo del botón al pasar el ratón por encima
        Args:
            button: configuramos el botón para cambiar el color(background).
        """
        button.config(bg=COLOR_CURSOR_ENCIMA, fg='white')

    def on_leave(self, event, button):
        """
        Restauramos el estilo del botón al salir el ratón
        Args:
            button: Configuramos el botón para asignarle un color al no apretarlo(background).
        """
        button.config(bg=COLOR_MENU_LATERAL, fg='white')

    def toggle_panel(self):
        """
        Alternamos la visibilidad del menú lateral.
        ARGS: 
            winfo_ismapped: Utilizamos la función para determinar si un widget está actualmente si es visible.
            pack_forget: Lo utilizamos para ocultar un widget 
            menu_lateral.pack: Asignamos que el menu lateral se encuentre forget, que este de forma LEFT y el fill "y"
        """
        if self.menu_lateral.winfo_ismapped():
            self.menu_lateral.pack_forget()
        else:
            self.menu_lateral.pack(side=tk.LEFT, fill='y')

    def volver_al_inicio(self):
        """
        Definimos la función de volver al inicio 
        Args:
            self.destroy()
        """
        self.destroy()