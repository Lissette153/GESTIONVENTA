import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel


class VentanaAgregarGasto(tk.Toplevel):
    """
    Clase para la ventana de agregar gasto. Permite al usuario ingresar la descripción, tipo, monto y fecha del gasto a través de un
    formulario.
    """

    def __init__(self, master):
        """
        Inicializamos la ventana de agregar gasto con sus componentes visuales y de entrada.
        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Generamos una etiqueta, incluyendo campo de entrada para la descripción, tipo, monto y fecha del gasto.
        3. Generamos un espacio(tk.Label) para el error en caso de que no se ingresen números en monto.
        3. Para permitirnos crear un gasto diseñamos e incluimos el botón que nos permitirá agregar el gasto.
        Args:
            master (tk.Tk, opcional): La ventana principal de la que se deriva esta ventana.
            Crud_Gasto: Vinculación del crud de  gastos para incluir todas sus funciones necesarias para realizar el programa.
            self.campo: Nos permite configurar el campo de texto.
            grid: Nos permite asignar un row, column, el padx(10) y el pady(10)
            tk.Label: Nos permite generar un texto que le dice al usuario que ingresar.
            tk.Entry: Nos permite que el usuario pueda agregar datos atraves de un formulario.s
            -----------------------------------------------------------------------------------------------
            tk.StringVar: Nos permite gestionar el valor de los widgets de entrada (en este caso númericos)
            tk.Label:  para un mensaje de error en caso de no ingresar valores númericos.
            tk.Entry(self, textvariable=self.valor_monto): Nos permite asignar un valor en la variable de campo para luego verificar que
            se agregan números y no caracteres.
            -----------------------------------------------------------------------------------------------
            button_agregar_gasto: Botón para agregar gasto(self.agregar_gasto).
        """
        super().__init__(master)
        self.configure(background="#ffd7be")
        self.title("Agregar Gasto")
        self.geometry("400x300")

        self.crud_gasto = CrudGasto()

        etiqueta_descripcion = tk.Label(self, text="Descripción:")
        etiqueta_descripcion.grid(row=0, column=0, padx=10, pady=10)
        self.campo_descripcion = tk.Entry(self)
        self.campo_descripcion.grid(row=0, column=1, padx=10, pady=10)

    
        etiqueta_tipo = tk.Label(self, text="Tipo:")
        etiqueta_tipo.grid(row=1, column=0, padx=10, pady=10)
        self.campo_tipo = tk.Entry(self)
        self.campo_tipo.grid(row=1, column=1, padx=10, pady=10)

        
        etiqueta_monto = tk.Label(self, text="Monto:")
        etiqueta_monto.grid(row=2, column=0, padx=10, pady=10)
        self.valor_monto = tk.StringVar(self)
        self.campo_monto = tk.Entry(self, textvariable=self.valor_monto)
        self.campo_monto.grid(row=2, column=1, padx=10, pady=10)
        self.etiqueta_error_monto = tk.Label(self, text="", fg="red")
        self.etiqueta_error_monto.grid(row=3, column=1, padx=10, pady=0, sticky="W")

        etiqueta_fecha = tk.Label(self, text="Fecha:")
        etiqueta_fecha.grid(row=4, column=0, padx=10, pady=10)
        self.campo_fecha = tk.Entry(self)
        self.campo_fecha.grid(row=4, column=1, padx=10, pady=10)

        boton_agregar = tk.Button(self, text="Agregar", command=self.agregar_gasto)
        boton_agregar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

    def validar_numeros(self, valor):
        """
        Nos permite validar que el valor ingresado sea un número(isdigit).
        Args:
            valor(str): Validar.

        Returns:
            bool: True si el valor es un número, False en caso contrario.
        """
        return valor.isdigit()

    def validar_entrada(self):
        """
        Nos permite validar la entrada del monto y muestra un mensaje de error si no es válido.

        Except:
            Si el valor es un número se agrega, en caso contrario muestra un mensaje de error(messagebox).
        """
        monto_valido = self.validar_numeros(self.valor_monto.get())

        if not monto_valido:
            self.etiqueta_error_monto.config(text="Error: Ingrese solo números.")
        else:
            self.etiqueta_error_monto.config(text="")

    def agregar_gasto(self):
        """"
        Nos permite agregar el gasto a la base de datos con los atributos ingresados y maneja los posibles errores. Donde también, 
        dentro del metodo obtenemos todos los datos ingresados de el gasto

        Validamos que todos los campos estén completos a través de un if.
         
        Y validamos la entrada de texto(númerico o caracter).

        Except:
            En caso de que las condiciones no se cumplan "Los datos no estan completos", " "No se pudo agregar el gasto", 
            "Error al agregar el gasto", mostramos un error(messagebox).
        Return:    
            self.crud_venta.agregar_gasto: Agregamos el gasto a la base de datos con sus respectivos atributos con su id.
            self.destroy(): Despúes de ingresar el gasto, destruimos la ventana(o frame).
    
        """
        descripcion = self.campo_descripcion.get()
        tipo = self.campo_tipo.get()
        monto = self.valor_monto.get()
        fecha_gasto = self.campo_fecha.get()

        if not descripcion or not tipo or not monto or not fecha_gasto:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return
        
        try:
            id_gasto = self.crud_gasto.agregar_gasto(descripcion, tipo, monto, fecha_gasto)
            if id_gasto:
                messagebox.showinfo("Éxito", "Gasto agregado correctamente.")
                self.destroy()
            else:
                messagebox.showerror("Error", "No se pudo agregar el gasto.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al agregar el gasto: {e}")
