import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel

#DENTRO DE ESTE FRAME EL USUARIO PODRA MODIFICAR EL PRODUCTO SELECCIONADO POR EL EN LA LISTA DE PRODUCTOS.

class VentanaModificarProducto(tk.Toplevel):
    """
    Clase para la ventana de modificar PRODUCTO. Permite al usuario modificar el nombre, precio y stock de la tabla producto a través de un
    formulario.
    """
    def __init__(self, parent, id_producto, producto):
        """
        Inicializamos la ventana de modificar producto con sus componentes visuales y de entrada.
        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Inicializamos el CRUD de productos para interactuar con la base de datos.
        3. Generamos una etiqueta, incluyendo campo de entrada para el nombre, precio y stock del producto a modificar.
        4. Generamos un espacio(tk.Label) para el error en caso de que no se ingresen números en precio y stock.
        5. Para permitirnos modificar un producto diseñamos e incluimos el botón que nos permitirá modificar.
        6. Generamos un botón para volver a la vista de productos sin guardar cambios con el comando(metodo) y self.
        7. Verificamos si el producto existe(if); si no, muestra un error(messagebox) y cierra la ventana(self.destroy).
        ARGS:
            master (tk.Tk, opcional): La ventana principal de la que se deriva esta ventana.
            Crud_Producto: Vinculación del crud de productos para incluir todas sus funciones necesarias para realizar el programa.
            ID_PRODUCTO: Asignamos una id para poder modificar el producto.
            tk.Label: Nos permite generar un texto que le dice al usuario que ingresar.
            tk.StringVar: Nos permite gestionar el valor de los widgets de entrada (en este caso númericos)
             
            tk.Entry: Nos permite que el usuario pueda agregar datos atraves de un formulario.
          
            button_modificar_producto: Botón para guardar los cambios realizados al producto con el comando(metodo) y self.guardar_cambios.
            boton_volver =  Botón para volver a la lista de productos con el comando(metodo) y self.volver_productos.
        """
        super().__init__(parent)
        self.configure(background="#ffd7be")
        self.title("Modificar Producto")
        self.geometry("400x300")

        self.crud_producto = CrudProducto()
        self.id_producto = id_producto

        etiqueta_nombre = tk.Label(self, text="Nombre:")
        etiqueta_nombre.grid(row=0, column=0, padx=10, pady=10)
        self.campo_nombre = tk.Entry(self)
        self.campo_nombre.grid(row=0, column=1, padx=10, pady=10)

        etiqueta_precio = tk.Label(self, text="Precio:")
        etiqueta_precio.grid(row=1, column=0, padx=10, pady=10)
        self.valor_precio = tk.StringVar(self)
        self.campo_precio = tk.Entry(self)
        self.campo_precio.grid(row=1, column=1, padx=10, pady=10)
        self.etiqueta_error_precio = tk.Label(self, text="", fg="red")
        self.etiqueta_error_precio.grid(row=2, column=1, padx=10, pady=5)

        etiqueta_stock = tk.Label(self, text="Stock:")
        etiqueta_stock.grid(row=4, column=0, padx=10, pady=10)
        self.valor_stock = tk.StringVar(self)
        self.campo_stock = tk.Entry(self)
        self.campo_stock.grid(row=4, column=1, padx=10, pady=10)
        self.etiqueta_error_stock = tk.Label(self, text="", fg="red")
        self.etiqueta_error_stock.grid(row=6, column=1, padx=10, pady=5)

        boton_guardar = tk.Button(self, text="Guardar cambios", command=self.guardar_cambios)
        boton_guardar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

        boton_volver = tk.Button(self, text="Volver a los productos", command=self.volver_productos)
        boton_volver.grid(row=6, column=0, columnspan=2, padx=10, pady=10)

        if producto == None:
            messagebox.showerror("Error", "Producto no encontrado.")
            self.destroy()

    
    def guardar_cambios(self):
        """Definimos el método para guardar los cambios realizados al producto en la base de datos y sus atributos.
           Modificamos los datos(atributos: nombre, precio y stock) del producto(crud) en la base de datos.
        ARGS:
            nombre: self.campo_nombre.get()
            precio: self.campo_precio.get()
            stock: self.campo_stock.get()
        Except:
            Si el precio o stock no es un número, se muestra un error.
            Validamos (if) que todos los campos estén completos y si no es asi lanzamos un mensaje de error(messagebox).
            En caso de que no se pueda modificar el producto, lanzamos un error(messagebox)

            
        """
        nombre = self.campo_nombre.get()
        precio = self.campo_precio.get()
        stock = self.campo_stock.get()
   

        if not nombre or not precio or not stock:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return
        
        try:
            self.crud_producto.modificar_producto(nombre, precio, stock, self.id_producto)
            messagebox.showinfo("Éxito", "Producto modificado correctamente.")
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Error al modificar el producto: {e}")

    def volver_productos(self):
        """ Definimos el método para volver a la vista de productos (self.destroy()).
        """
        self.destroy()

