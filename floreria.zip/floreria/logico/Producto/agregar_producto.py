import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel

#DENTRO DE ESTE FRAME AGREGAREMOS LOS PRODUCTOS DESEADOS POR EL USUARIO.

class VentanaAgregarProducto(tk.Toplevel):
    """
    Clase para el productona de agregar PRODUCTO. Permite al usuario ingresar el nombre, precio, descripción, categoria y stock de la tabla producto a través de un
    formulario.
    """
    def __init__(self, master):
        """
        Inicializamos el productona de agregar producto con sus componentes visuales y de entrada.
        1. Inicializamos el productona y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Inicializamos el CRUD de productos para interactuar con la base de datos.
        3. Generamos una etiqueta, incluyendo campo de entrada para el nombre, precio, descripción, categoria y stock del producto.
        4. Generamos un espacio(tk.Label) para el error en caso de que no se ingresen números en precio y stock.
        5. Para permitirnos crear un  producto diseñamos e incluimos el botón que nos permitirá agregarlo.
        Args:
            master (tk.Tk, opcional): el productona principal de la que se deriva esta ventana.
            Crud_Producto: Vinculación del crud de productos para incluir todas sus funciones necesarias para realizar el programa.
            tk.Label: Nos permite generar un texto que le dice al usuario que ingresar.
            self.campo: Nos permite configurar el campo de texto.
            grid: Nos permite asignar un row, column, el padx(10) y el pady(10)
            tk.Entry: Nos permite que el usuario pueda agregar datos atraves de un formulario.
            ------------------------------------------------------------------------
            tk.StringVar: Nos permite gestionar el valor de los widgets de entrada (en este caso númericos)
            tk.Label:  para un mensaje de error en caso de no ingresar valores númericos.
            tk.Entry(self, textvariable=self.valor_monto): Nos permite asignar un valor en la variable de campo para luego verificar que
            se agregan números y no caracteres.
            ------------------------------------------------------------------------
            button_agregar_producto: Botón para agregar el producto(self.agregar_producto).
        """
        super().__init__(master)
        self.configure(background="#ffd7be")
        self.title("Agregar Producto")
        self.geometry("400x300")

        self.crud_producto = CrudProducto()
        etiqueta_nombre = tk.Label(self, text="Nombre:")
        etiqueta_nombre.grid(row=0, column=0, padx=10, pady=10)
        self.campo_nombre = tk.Entry(self)
        self.campo_nombre.grid(row=0, column=1, padx=10, pady=10)

    
        etiqueta_precio = tk.Label(self, text="Precio:")
        etiqueta_precio.grid(row=1, column=0, padx=10, pady=10)
        self.valor_precio = tk.StringVar(self)
        self.campo_precio = tk.Entry(self, textvariable=self.valor_precio)
        self.campo_precio.grid(row=1, column=1, padx=10, pady=10)
        self.etiqueta_error_precio = tk.Label(self, text="", fg="red")
        self.etiqueta_error_precio.grid(row=2, column=1, padx=10, pady=5)

        etiqueta_descripcion = tk.Label(self, text="Descripción:")
        etiqueta_descripcion.grid(row=3, column=0, padx=10, pady=10)
        self.campo_descripcion = tk.Entry(self)
        self.campo_descripcion.grid(row=3, column=1, padx=10, pady=10)
        etiqueta_categoria = tk.Label(self, text="Categoría:")
        etiqueta_categoria.grid(row=4, column=0, padx=10, pady=10)
        self.campo_categoria = tk.Entry(self)
        self.campo_categoria.grid(row=4, column=1, padx=10, pady=10)

        etiqueta_stock = tk.Label(self, text="Stock:")
        etiqueta_stock.grid(row=5, column=0, padx=10, pady=10)
        self.valor_stock = tk.StringVar(self)
        self.campo_stock = tk.Entry(self, textvariable=self.valor_stock)
        self.campo_stock.grid(row=5, column=1, padx=10, pady=10)
        self.etiqueta_error_stock = tk.Label(self, text="", fg="red")
        self.etiqueta_error_stock.grid(row=6, column=1, padx=10, pady=5)

        boton_agregar = tk.Button(self, text="Agregar", command=self.agregar_producto)
        boton_agregar.grid(row=7, column=0, columnspan=2, padx=10, pady=10)

    
    def validar_numeros(self, valor):
        """
        Nos permite validar que el valor ingresado sea un número(isdigit).
        Args:
            valor(str): Validar.

        Returns:
            bool: True si el valor es un número, False en caso contrario.
        """
        return valor.isdigit()

    def validar_entrada(self):
        """
        Nos permite validar la entrada del precio y stock, mientras que si la condición no se cumple, 
        muestra un mensaje de error si no es válido.

        Con config y text donde la etiqueta ya anterior estaba definida.

        Except:
            Si el valor es un número se agrega, en caso contrario muestra un mensaje de error/(messagebox).
        """
        precio_valido = self.validar_numeros(self.valor_precio.get())
        stock_valido = self.validar_numeros(self.valor_stock.get())

        if not precio_valido:
            self.etiqueta_error_precio.config(text="Error: Ingrese solo números.")
        else:
            self.etiqueta_error_precio.config(text="")

        if not stock_valido:
            self.etiqueta_error_stock.config(text="Error: Ingrese solo números.")
        else:
            self.etiqueta_error_stock.config(text="")

        return precio_valido and stock_valido

    def agregar_producto(self):
        """"
        Nos permite agregar el producto a la base de datos con los atributos ingresados y maneja los posibles errores. Donde también, 
        dentro del metodo obtenemos todos los datos ingresados de el producto

        Validamos que todos los campos estén completos a través de un if.
         
        Y validamos la entrada de texto(númerico o caracter).

        Except:
            En caso de que las condiciones no se cumplan "Los datos no estan completos", " "No se pudo agregar el producto", 
            "Error al agregar el producto", mostramos un error(messagebox).
        Return:    
            self.crud_venta.agregar_producto: Agregamos el producto a la base de datos con sus respectivos atributos con su id.
            self.destroy(): Despúes de ingresar el producto, destruimos la ventana(o frame).
    
        """
        nombre = self.campo_nombre.get()
        precio = self.campo_precio.get()
        descripcion = self.campo_descripcion.get()
        categoria = self.campo_categoria.get()
        stock = self.campo_stock.get()


        if not nombre or not precio or not descripcion or not categoria or not stock:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return

        if not self.validar_entrada():
            return

    
        try:
            id_producto = self.crud_producto.agregar_producto(nombre, precio, descripcion, categoria, stock)
            if id_producto:
                messagebox.showinfo("Éxito", "Producto agregado correctamente.")
                self.destroy()
            else:
                messagebox.showerror("Error", "No se pudo agregar el producto.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al agregar el producto: {e}")

