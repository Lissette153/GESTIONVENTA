import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel

#FRAME DE INFORME DE VENTAS DONDE EL USUARIO PODRA REVISAR EL TOTAL DE VENTAS DE ACUERDO A LA FECHA ASIGNADA.

class VentanaInformeVentas(tk.Toplevel):
    """""
     Clase para la ventana de informes de VENTA. Permite al usuario ingresar la fecha y la aplicación realiza una búsqueda de esta.
     Si existe, muestra los datos de esa venta y calcula el total de esa/s ventas en esa fecha.
    """
    def __init__(self, master):
        """
         Inicializamos la ventana de informe de venta con sus componentes visuales y de entrada.
        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Inicializamos el CRUD de ventas para interactuar con la base de datos.
        3. Generamos una  etiqueta  y campo de entrada para la fecha de la venta a buscar.
        4. Incluimos un botón para  generar el informe de ventas con un comando(metodo) y self.
        Args:
            master (tk.Tk, opcional): La ventana principal de la que se deriva esta ventana.
            Crud_Venta: Vinculación del crud de venta para incluir todas sus funciones necesarias para realizar el programa.
            tk.Label: Nos permite generar un texto que le dice al usuario que ingresar.
            self.campo: Nos permite configurar el campo de texto.
            grid: Nos permite asignar un row, column, el padx(10) y el pady(10)
            tk.Entry: Nos permite que el usuario pueda agregar datos.
            ---------------------------------------------------------------------
            tk.Button: Nos permite generar un botón que nos permitirá buscar la venta.
            button_generar: Botón para generar el informe de venta(self.generar_informe).
        """
        super().__init__(master)
        self.title("Informe de Ventas")
        self.geometry("400x200")
        self.configure(background="#ffd7be")
        self.crud_venta = CrudVenta()

        etiqueta_fecha = tk.Label(self, text="Fecha:")
        etiqueta_fecha.grid(row=0, column=0, padx=10, pady=10)
        self.campo_fecha = tk.Entry(self)
        self.campo_fecha.grid(row=0, column=1, padx=10, pady=10)


        boton_generar = tk.Button(self, text="Generar Informe", command=self.generar_informe)
        boton_generar.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

    def generar_informe(self):
        """Definimos el método para generar el informe  a traves de una fecha.
        1. Inicializamos la variable fecha para obtener la fecha ingresada por el usuario.
        2. Validamos la fecha ingresada y si no  existe dirigimos un mensaje de error.
        3. Obtenemos el informe de ventas a traves de una función de calculo de ventas(metodo) con el crud de venta.
        4. Si existe el informe de ventas, lo mostramos en otra ventana con sus atributos (id, fecha, total, estado de pago y cantidad)
        5. Generamos la obtención de ventas con sus respectivos atributos(id_venta, fecha, total, estado_pago, cantidad)
        6. Generamos el total de ventas con la ventana de informe y el total de ventas asignado a cada una (donde si hay mas de 1 se suma).
        Args:
            self.campo_fecha: Nos permite obtener la fecha ingresada por el usuario.
            self.crud_venta: Nos permite obtener el crud de venta para interactuar con la base de datos.
            calcular_monto_total_ventas (fecha): Nos permite calcular el monto total de ventas a través de su fecha ingresada(ventas, total_ventas).
            ttk.Treeview:Nos proporciona una tabla o una vista jerárquica de elementos.
            self.lista_ventas: Nos permite generar una lista de ventas  con donde tendremos asignados cada columna y sus datos de la tabla de ventas.
            heading: Nos permite configurar los encabezados de las columnas en el widget.
            lista_ventas.insert: Nos permite obtener los datos insertados anteriormente para mostrarlos previamente.
            ttk.Label: Nos permite generar un texto.
            etiqueta_total: Asignamos un texto donde mostramos el total de ventas calculados.
        
        Except:
            ValueError: Nos permite generar un mensaje de error si la fecha ingresada no existe.(messagebox)
            messagebox: Nos permite generar un mensaje de error al no poder generar un informe.
        """
        fecha = self.campo_fecha.get()
        if not fecha:
            messagebox.showwarning("Error", "Por favor, ingrese una fecha.")
            return

        try:
            ventas, total_ventas = self.crud_venta.calcular_monto_total_ventas(fecha)

            ventana_informe = tk.Toplevel(self)
            ventana_informe.title("Informe de Ventas")
            ventana_informe.geometry("400x300")
    
            self.lista_ventas = ttk.Treeview(ventana_informe, columns=("id_venta","fecha", "total", "estado_pago", "cantidad"), show="headings")
            self.lista_ventas.heading("id_venta", text="Fecha")
            self.lista_ventas.heading("fecha", text="Fecha")
            self.lista_ventas.heading("total", text="Total")
            self.lista_ventas.heading("estado_pago", text="Estado de pago")
            self.lista_ventas.heading("cantidad", text="Cantidad")
            self.lista_ventas.pack()

            for venta in ventas:
                ventas = self.crud_venta.obtener_venta()
                self.lista_ventas.insert("", tk.END, values=(venta.get('id_venta'), venta.get('fecha'), venta.get('total'), venta.get('estado_pago'),venta.get('cantidad')))

            etiqueta_total = tk.Label(ventana_informe, text=f"Total de ventas: {total_ventas}")
            etiqueta_total.pack(pady=10)

        except Exception as e:
            messagebox.showerror("Error", f"Error al generar el informe: {e}")
