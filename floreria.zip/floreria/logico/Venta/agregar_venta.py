import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel

#FRAME PARA QUE EL USUARIO PUEDA AGREGAR UNA VENTA
class VentanaAgregarVenta(tk.Toplevel):
    """
    Clase para la ventana de agregar VENTA. Permite al usuario ingresar la fecha, total, estado de pago, descripción y cantidad de la 
    tabla venta a través de un formulario.
    """
    def __init__(self, master):
        """
        Inicializamos la ventana de agregar venta con sus componentes visuales y de entrada.
        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño).
        2. Inicializamos el CRUD de ventas para interactuar con la base de datos.
        3. Generamos una etiqueta, incluyendo campo de entrada para la fecha, total, descripción y cantidad de la venta.
        4. Generamos un espacio(tk.Label) para el error en caso de que no se ingresen números total y cantidad.
        5. Para permitirnos crear un venta diseñamos e incluimos el botón que nos permitirá agregarlo.
        Args:
            master (tk.Tk, opcional): La ventana principal de la que se deriva esta ventana.
            Crud_Venta: Vinculación del crud de venta para incluir todas sus funciones necesarias para realizar el programa.
            tk.Label: Nos permite generar un texto que le dice al usuario que ingresar.
            self.campo: Nos permite configurar el campo de texto.
            grid: Nos permite asignar un row, column, el padx(10) y el pady(10)
            tk.Entry: Nos permite que el usuario pueda agregar datos atraves de un formulario.
            ---------------------------------------------------------------------
            tk.Label:  para un mensaje de error en caso de no ingresar valores númericos.
            tk.StringVar: Nos permite gestionar el valor de los widgets de entrada (en este caso númericos)
            tk.Entry(self, textvariable=self.valor_monto): Nos permite asignar un valor en la variable de campo para luego verificar que
            se agregan números y no caracteres.
            ---------------------------------------------------------------------------
            self.campo.set: Nos permite asignar un mensaje de "Asignar" Para las opciones.
            tk.OptionMenu: Nos permite asignar las opciones de "Pagado" o "No Pagado".
            ---------------------------------------------------------------------------
            tk.Button: Nos permite generar un botón que nos permitirá agregar la venta.
            button_agregar_venta: Botón para agregar la venta(self.agregar_venta).
        
        """
        super().__init__(master)
        self.configure(background="#ffd7be")
        self.title("Agregar Venta")
        self.geometry("400x300")

        self.crud_venta = CrudVenta()
        etiqueta_fecha = tk.Label(self, text="Fecha:")
        etiqueta_fecha.grid(row=0, column=0, padx=10, pady=10)
        self.campo_fecha = tk.Entry(self, textvariable=self.valor_fecha)
        self.campo_fecha.grid(row=0, column=1, padx=10, pady=10)

        etiqueta_total = tk.Label(self, text="Total:")
        etiqueta_total.grid(row=2, column=0, padx=10, pady=10)
        self.valor_total = tk.StringVar(self)
        self.campo_total = tk.Entry(self, textvariable=self.valor_total)
        self.campo_total.grid(row=2, column=1, padx=10, pady=10)
        self.etiqueta_error_total = tk.Label(self, text="", fg="red")
        self.etiqueta_error_total.grid(row=3, column=1, padx=10, pady=0, sticky="W")
                                       
        etiqueta_estado_pago = tk.Label(self, text="Estado de pago:")
        etiqueta_estado_pago.grid(row=4, column=0, padx=10, pady=10)
        self.campo_estado_pago = tk.StringVar(self)
        self.campo_estado_pago.set("Seleccionar")
        opciones_estado_pago = ["Seleccionar", "No pagado", "Pagado"]
        menu_estado_pago = tk.OptionMenu(self, self.campo_estado_pago, *opciones_estado_pago)
        menu_estado_pago.grid(row=4, column=1, padx=10, pady=10)

        etiqueta_descripcion = tk.Label(self, text="Descripción:")
        etiqueta_descripcion.grid(row=6, column=0, padx=10, pady=10)
        self.campo_descripcion = tk.Entry(self)
        self.campo_descripcion.grid(row=6, column=1, padx=10, pady=10)


        etiqueta_cantidad = tk.Label(self, text="Cantidad:")
        etiqueta_cantidad.grid(row=7, column=0, padx=10, pady=10)
        self.valor_cantidad = tk.StringVar(self)
        self.campo_cantidad = tk.Entry(self, textvariable=self.valor_cantidad)
        self.campo_cantidad.grid(row=7, column=1, padx=10, pady=10)
        self.etiqueta_error_cantidad = tk.Label(self, text="", fg="red")
        self.etiqueta_error_cantidad.grid(row=8, column=1, padx=10, pady=0, sticky="W")

        boton_agregar = tk.Button(self, text="Agregar", command=self.validar_entrada)
        boton_agregar.grid(row=9, column=0, columnspan=2, padx=10, pady=10)

    def validar_numeros(self, valor):
        """
        Nos permite validar que el valor ingresado sea un número(isdigit).
        Args:
            valor(str): Validar.

        Returns:
            bool: True si el valor es un número, False en caso contrario.
        """
        return valor.isdigit()


    def validar_entrada(self):
        """
        Nos permite validar la entrada del total  y cantidad, mientras que si la condición no se cumple, 
        muestra un mensaje de error si no es válido.

        Con config y text donde la etiqueta ya anterior estaba definida.

        Except:
            Si el valor es un número se agrega, en caso contrario muestra un mensaje de error(messagebox).
        """
        total_valido = self.validar_numeros(self.valor_total.get())
        cantidad_valido = self.validar_numeros(self.valor_cantidad.get())

        if not total_valido:
            self.etiqueta_error_total.config(text="Error: Ingrese solo números.")
        else:
            self.etiqueta_error_total.config(text="")

        if not cantidad_valido:
            self.etiqueta_error_cantidad.config(text="Error: Ingrese solo números.")
        else:
            self.etiqueta_error_cantidad.config(text="")

        if total_valido and cantidad_valido:
            self.agregar_venta()

  
    def agregar_venta(self):
        """"
        Nos permite agregar la venta a la base de datos con los atributos ingresados y maneja los posibles errores. Donde también, 
        dentro del metodo obtenemos todos los datos ingresados de la venta

        Validamos que todos los campos estén completos a través de un if, incluyendo además del estado de pago donde se incluira un 
        "Seleccionar".

        Verificamos(if) que el estado de pago se muestre las opciones al momento de ingresar: "Pagado": 0 y "No Pagado":1. 
        De forma que sea comprensible para el usuario  al momento de revisar sus ventas

        Except:
            En caso de que las condiciones no se cumplan "Los datos no estan completos", "No se selecciona un estado de pago", 
            "No se pudo agregar la venta", "Error al agregar la venta", mostramos un error(messagebox).
        Return:    
            self.crud_venta.agregar_venta: Agregamos la venta a la base de datos con sus respectivos atributos  con su id.
            self.destroy(): Despúes de ingresar la venta, destruimos la ventana(o frame).
        """
        fecha = self.campo_fecha.get()
        total = self.campo_total.get()
        estado_pago = self.campo_estado_pago.get().strip()
        descripcion = self.campo_descripcion.get()
        cantidad = self.campo_cantidad.get()

        if not fecha or not total or estado_pago == "Seleccionar" or not descripcion or not cantidad:
            messagebox.showwarning("Error", "Por favor, complete todos los campos y seleccione un estado de pago válido.")
            return
        estado_pago_db = 1 if estado_pago == "No pagado" else 0 if estado_pago == "Pagado" else None
        if estado_pago_db is None:
            messagebox.showwarning("Error", "Por favor, seleccione un estado de pago válido.")
            return

        try:
            id_venta = self.crud_venta.agregar_venta(fecha, total, estado_pago_db, descripcion, cantidad)
            if id_venta:
                messagebox.showinfo("Éxito", "Venta agregada correctamente.")
                self.destroy()
            else:
                messagebox.showerror("Error", "No se pudo agregar la venta.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al agregar la venta: {e}")


