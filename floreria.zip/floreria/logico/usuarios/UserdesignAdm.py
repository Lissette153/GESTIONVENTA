import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from tkinter import font
from tkinter import *
from Presentacion.config import COLOR_BARRA_SUPERIOR
import Presentacion.util.util_ventanas as util_ventana
from BD.crud import *
from BD.modelo import *


#FRAME PARA GESTIÓN DE USUARIOS

class UserDesign(tk.Tk):
    """
    Clase que contiene la interfaz de la ventana de gestión de usuarios, la cuál nos permitira: AGREGAR USUARIOS, MODIFICARLOS, 
    ELIMINAR Y LO MAS IMPORTANTE, LISTARLOS.
    TAMBIÉN INCLUIMOS UNA INTERFAZ DE USUARIO BASTANTE AMIGABLE.
    """
    def __init__(self):
        """Inicializamos la ventana de Usuarios con sus respectivos componentes.

        1. Inicializamos la ventana y sus configuraciones básicas (título, color de fondo, tamaño)
        2. Inicializamos el frame de la ventana de usuarios.
        3. Agregamos los frame de botones y control de la barra superior para el panel de gestión de usuarios.
        4. Definimos el método para configurar los botones y la lista de usuarios (dimensiones, color de barra)
        """
        super().__init__()
        self.geometry("300x200")
        self.configure(background="#ffd7be")
        self.title("Gestor de Usuarios")
        self.botones()
        self.control_barra_superior()

    def botones(self):
        """" Configuramos las dimensiones de la ventana y centramos la ventana.
        1. Generamos un self y tk.Frame de la barra superior de la ventana con su configuración
        2. Inicializamos el CRUD de usuarios para interactuar con la base de datos
        3. Generamos el frame para la lista de usuarios con tk.Treeview
        4. Configuramos de la tabla de usuarios con tk.Treview, la lista de usuarios, sus columnas(rut, nombre, rol, privilegios y email)
        5. Generamos la lista de usuarios con un heading, con sus atributos y su nombre de cada uno que representara cada columna de estos.
        6. Generamos un botón para modificar un usuario a traves de tk.Button
        7. Generamos un botón para agregar un nuevo usuario a traves de tk.Button
        8. Generamos un botón para eliminar un usuario a traves de tk.Button
        9. Generamos un botón para volver hacia el panel de administrador a traves de tk.Button y un comando(metodo) de self 
        Args:
            Tk.Frame: Nos permite configurar el background de la barra superior.
            self.pack: Nos permite indicar donde estara situado y cuanto llenara la barra.
            CRUD: Nos permite interactuar con la base de datos.
            tk.Treeview: Nos permite generar una tabla de usuarios con un frame de lista de usuarios.
            tk.Treview: Nos permite configurar la tabla de usuarios con sus columnas con su lista de usuarios.
            heading: Nos permite asignar una columna para cada atributo con su respectivo identificador
            tk.Button: Nos permite generar los botones para modificar, agregar, eliminar y volver al panel con su respectivo pady(10)



        """
        w, h = 1024, 600
        util_ventana.centrar_ventana(self, w, h)
        
        self.barra_superior = tk.Frame(self, bg=COLOR_BARRA_SUPERIOR, height=50)
        self.barra_superior.pack(side=tk.TOP, fill='both')
        self.crud_usuario = CrudUsuario()

        frame_lista_usuarios = ttk.Treeview(self)
        frame_lista_usuarios.pack(pady=10)

        self.lista_usuarios = ttk.Treeview(frame_lista_usuarios, columns=("rut", "nombre", "rol", "privilegios", "email"), show="headings")
        self.lista_usuarios.heading("rut", text="RUT DEL USUARIO")
        self.lista_usuarios.heading("nombre", text="Nombre")
        self.lista_usuarios.heading("rol", text="Rol")
        self.lista_usuarios.heading("privilegios", text="Privilegios")
        self.lista_usuarios.heading("email", text="Email")
        self.lista_usuarios.pack()

        boton_modificar = tk.Button(self, text="Modificar")
        boton_modificar.pack(pady=10)

        boton_agregar = tk.Button(self, text="Agregar Usuario")
        boton_agregar.pack(pady=10)

        boton_eliminar = tk.Button(self, text="Eliminar Usuario")
        boton_eliminar.pack(pady=10)

        boton_volver = tk.Button(self, text="Volver hacia atrás", command=self.volver_al_inicio)
        boton_volver.pack(pady=10)

    
    def actualizar_lista_usuarios(self):
        """Actualiza la lista de usuarios en la tabla de usuarios, donde
        definimos el metodo y utilizamos una eliminación de la lista antigua (delete) y obtenemos
         una nueva lista (get_children y obtener_usuarios)
         Args:
            self: Nos permite interactuar con la base de datos.
            self.lista_usuarios: Nos permite interactuar con la tabla de usuarios.
            self.crud_usuario: Nos permite interactuar con la base de datos.
            lista_usuarios.insert:  Insertamos los nuevos datos de usuario a traves de una lista.
        """
        self.lista_usuarios.delete(*self.lista_usuarios.get_children())
        usuarios = self.crud_usuario.obtener_usuarios()
        for usuario in usuarios:
            self.lista_usuarios.insert("", tk.END, values=(usuario.obtener_rut(), usuario.obtener_nombre(), usuario.obtener_rol(), usuario.obtener_privilegio(), usuario.obtener_email()))


    def control_barra_superior(self):
        """Controla la barra superior de la ventana de usuarios, donde
        definimos el método para asignar a  la barra superior de la ventana una fuente de letra y su tamaño.
        
        Incluimos un titulo ("Panel de gestión de usuarios Floreria La Blanco")
        Incluimos el correo de la floreria  a cargo de la aplicación en caso de alguna consulta o queja en la barra superior.
        Args:
            tk.label: Titulo de la barra superior
            config: Configuramos el background, la fuente, pady(10) y width(156) PARA TITULO
            pack: Configuramos la ubicación del titulo (LEFT).

            tk.label: Correo de la floreria a cargo de la aplicación.
            config: Configuramos el background, la fuente, pady(10) y width(20)
            pack: Configuramos la ubicación del correo (RIGHT).
        """
        font_awesome = font.Font(family='FontAwesome', size=12)

        self.Labeltitulo = tk.Label(self.barra_superior, text="Panel de gestión de usuarios Floreria La Blanco")
        self.Labeltitulo.config(fg="#fff", font=("Roboto", 15), bg=COLOR_BARRA_SUPERIOR, pady=10, width=156)
        self.Labeltitulo.pack(side=tk.LEFT)
        
        self.labelTitulo = tk.Label(self.barra_superior, text="joisyda0512@gmail.com")
        self.labelTitulo.config(fg="#fff", font=("Roboto", 10), bg=COLOR_BARRA_SUPERIOR, padx=10, width=20)
        self.labelTitulo.pack(side=tk.RIGHT)

    def volver_al_inicio(self):
        """Volvemos al inicio de la aplicación, donde
        definimos el método para volver al inicio de la aplicación.
        Args:
            self.destroy()
        """
        self.destroy()

