import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *
from tkinter import Toplevel


def mostrar_ventana_productos(self):
    ventana_productos = VentanaProductos(self)
    ventana_productos.grab_set()

def ventana_modificar_producto(self):
    ventana_productos = VentanaModificarProducto(self)
    ventana_productos.grab_set()


class VentanaProductos(tk.Toplevel):

    def __init__(self, master= None):
        super().__init__(master)
        self.configure(background="#ffd7be")
        self.title("Productos")
        self.geometry("600x400")

        self.crud_producto = CrudProducto()

        # Frame para la lista de productos
        frame_lista_productos = tk.Frame(self)
        frame_lista_productos.pack(pady=10)

        # Lista de productos
        self.lista_productos = ttk.Treeview(frame_lista_productos, columns=("id_producto","nombre", "precio", "descripcion", "categoria", "stock"), show="headings")
        self.lista_productos.heading("id_producto", text="ID")
        self.lista_productos.heading("nombre", text="Nombre")
        self.lista_productos.heading("precio", text="Precio")
        self.lista_productos.heading("descripcion", text="Descripción")
        self.lista_productos.heading("categoria", text="Categoría")
        self.lista_productos.heading("stock", text="Stock")
        self.lista_productos.pack()

        # Botón para actualizar la lista
        boton_modificar = tk.Button(self, text="Modificar", command=self.modificar_producto)
        boton_modificar.pack(pady=10)

        # Botón para agregar un nuevo producto
        boton_agregar = tk.Button(self, text="Agregar Producto", command=self.mostrar_ventana_agregar_producto)
        boton_agregar.pack(pady=10)

        # Botón para eliminar un producto
        boton_eliminar = tk.Button(self, text="Eliminar Producto", command=self.eliminar_producto)
        boton_eliminar.pack(pady=10)

        boton_actualizar = tk.Button(self, text="Actualizar la lista de Productos", command=self.actualizar_lista_productos)
        boton_actualizar.pack(pady=10)
        self.actualizar_lista_productos()

        boton_volver = tk.Button(self, text="Volver hacia atras", command= self.volver_al_inicio)
        boton_volver.pack(pady=10)

    def volver_al_inicio(self):
        self.destroy()  
        form_inicio = self.volver_main
        form_inicio.mainloop()

    def volver_main(self):
        self.destroy()

    def actualizar_lista_productos(self):
        self.lista_productos.delete(*self.lista_productos.get_children())
        productos = self.crud_producto.obtener_productos()

        for producto in productos:
            self.lista_productos.insert("", tk.END, values=(producto.obtener_nombre(), producto.obtener_precio(), producto.obtener_descripcion(), producto.obtener_categoria(), producto.obtener_stock(), producto.obtener_id()))

    def mostrar_ventana_agregar_producto(self):
        ventana_agregar_producto = VentanaAgregarProducto(self)
        ventana_agregar_producto.grab_set() 
    
    def modificar_producto(self):
        seleccion = self.lista_productos.selection()
        if seleccion:
            id_producto = self.lista_productos.item(seleccion[0], "values")[0]
            producto = self.crud_producto.buscar_producto(id_producto)
            if producto:
                ventana_modificar_producto = VentanaModificarProducto(self, id_producto, producto)
                ventana_modificar_producto.grab_set()
            else:
                messagebox.showerror("Error", "Producto no encontrado.")
        else:
            messagebox.showwarning("Error", "Seleccione un producto para modificar.")


    def eliminar_producto(self):
        # Obtener el ID del producto seleccionado
        seleccion = self.lista_productos.selection()
        if seleccion:
            id_producto = self.lista_productos.item(seleccion[0], "values")[0]

            # Confirmar la eliminación
            if messagebox.askyesno("Confirmar Eliminación", "¿Está seguro de que desea eliminar este producto?"):
                # Eliminar el producto de la base de datos
                self.crud_producto.eliminar_producto(id_producto)
        else:
            messagebox.showwarning("Error", "Seleccione un producto para eliminar.")

class VentanaModificarProducto(tk.Toplevel):
    def __init__(self, parent, id_producto, producto):
        super().__init__(parent)
        self.configure(background="#ffd7be")
        self.title("Modificar Producto")
        self.geometry("400x300")

        self.crud_producto = CrudProducto()
        self.id_producto = id_producto
        
        etiqueta_nombre = tk.Label(self, text="Nombre:")
        etiqueta_nombre.grid(row=0, column=0, padx=10, pady=10)
        self.campo_nombre = tk.Entry(self)
        self.campo_nombre.grid(row=0, column=1, padx=10, pady=10)

        etiqueta_precio = tk.Label(self, text="Precio:")
        etiqueta_precio.grid(row=1, column=0, padx=10, pady=10)
        self.campo_precio = tk.Entry(self)
        self.campo_precio.grid(row=1, column=1, padx=10, pady=10)


        etiqueta_stock = tk.Label(self, text="Stock:")
        etiqueta_stock.grid(row=4, column=0, padx=10, pady=10)
        self.campo_stock = tk.Entry(self)
        self.campo_stock.grid(row=4, column=1, padx=10, pady=10)

        boton_guardar = tk.Button(self, text="Guardar cambios", command=self.guardar_cambios)
        boton_guardar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

        boton_volver = tk.Button(self, text="Volver a los productos", command=self.volver_productos)
        boton_volver.grid(row=6, column=0, columnspan=2, padx=10, pady=10)

        if producto == None:
            messagebox.showerror("Error", "Producto no encontrado.")
            self.destroy()



    def guardar_cambios(self):
        nombre = self.campo_nombre.get()
        precio = self.campo_precio.get()
        stock = self.campo_stock.get()
   
        if not nombre or not precio or not stock:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return
        
        # Modificar el producto en la base de datos
        try:
            self.crud_producto.modificar_producto( nombre, precio, stock, self.id_producto )
            messagebox.showinfo("Éxito", "Producto modificado correctamente.")
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Error al modificar el producto: {e}")
        
    def volver_productos(self):
        self.destroy()  
        form_inicio = self.volver_main
        form_inicio.mainloop()

    def volver_main(self):
        VentanaProductos()
        



class VentanaAgregarProducto(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.configure(background="#ffd7be")
        self.title("Agregar Producto")
        self.geometry("400x300")

        self.crud_producto = CrudProducto()

        # Etiqueta y campo para el nombre
        etiqueta_nombre = tk.Label(self, text="Nombre:")
        etiqueta_nombre.grid(row=0, column=0, padx=10, pady=10)
        self.campo_nombre = tk.Entry(self)
        self.campo_nombre.grid(row=0, column=1, padx=10, pady=10)

        # Etiqueta y campo para el precio
        etiqueta_precio = tk.Label(self, text="Precio:")
        etiqueta_precio.grid(row=1, column=0, padx=10, pady=10)
        self.campo_precio = tk.Entry(self)
        self.campo_precio.grid(row=1, column=1, padx=10, pady=10)

        # Etiqueta y campo para la descripción
        etiqueta_descripcion = tk.Label(self, text="Descripción:")
        etiqueta_descripcion.grid(row=2, column=0, padx=10, pady=10)
        self.campo_descripcion = tk.Entry(self)
        self.campo_descripcion.grid(row=2, column=1, padx=10, pady=10)

        # Etiqueta y campo para la categoría
        etiqueta_categoria = tk.Label(self, text="Categoría:")
        etiqueta_categoria.grid(row=3, column=0, padx=10, pady=10)
        self.campo_categoria = tk.Entry(self)
        self.campo_categoria.grid(row=3, column=1, padx=10, pady=10)

        # Etiqueta y campo para el stock
        etiqueta_stock = tk.Label(self, text="Stock:")
        etiqueta_stock.grid(row=4, column=0, padx=10, pady=10)
        self.campo_stock = tk.Entry(self)
        self.campo_stock.grid(row=4, column=1, padx=10, pady=10)

        # Botón para agregar el producto
        boton_agregar = tk.Button(self, text="Agregar", command=self.agregar_producto)
        boton_agregar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

    def agregar_producto(self):
        # Obtener los datos del producto
        nombre = self.campo_nombre.get()
        precio = self.campo_precio.get()
        descripcion = self.campo_descripcion.get()
        categoria = self.campo_categoria.get()
        stock = self.campo_stock.get()

        # Validar los datos
        if not nombre or not precio or not descripcion or not categoria or not stock:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return

        # Agregar el producto a la base de datos
        try:
            id_producto = self.crud_producto.agregar_producto(nombre, precio, descripcion, categoria, stock)
            if id_producto:
                messagebox.showinfo("Éxito", "Producto agregado correctamente.")
                self.destroy()
            else:
                messagebox.showerror("Error", "No se pudo agregar el producto.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al agregar el producto: {e}")
