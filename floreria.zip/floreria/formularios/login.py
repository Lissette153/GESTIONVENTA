__package__ = 'formularios'

import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from design.form_designL import DesignLocal
from design.form_design import Design
#--- INICIO LOGIN -------

class Login(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Floreria La Blanco")
        w, h = 1024, 280
        self.geometry(f"{w}x{h}")
        self.config()
        self.botones()
    

    def config(self):
        self.navbar_frame = tk.Frame(self, height=500)
        self.navbar_frame.pack(side=tk.TOP, fill='both')
        #TITULO
        font_awesome = font.Font(family='FontAwesome', size=12)
        self.LabelTitle = tk.Label(self.navbar_frame, text= "¡Bienvenido a Floreria La Blanco!",  bg="#e4717a", fg="black",)
        self.LabelTitle.config(font=("Arial", 35), pady=10, width=1000)
        self.LabelTitle.pack(side=tk.TOP)
        #PARRAFO
        self.LabelText = tk.Label(text= '¡Donde dentro de esta aplicación podra ingresar sus datos manteniendo un control de su negocio!', bg="#ffc0a9")
        self.LabelText.config(font=("Arial", 12), pady=10, width=100000)
        self.LabelText.pack(side=tk.TOP)
        
        #TITULO DE OPCIONES
        self.LabelOpciones = tk.Label(text="Iniciar según las opciones elegidas: ADMIN O LOCAL",  bg="#ffc0a9")
        self.LabelOpciones.config(font=("Arial", 15), pady=10, width=100)
        self.LabelOpciones.pack(side=tk.TOP)

  
    def botones(self):
        self.button_frame = tk.Frame(self, bg="#ffc0a9")
        self.button_frame.pack(side=tk.TOP, fill="both", pady=0)

        # Agregamos los botones dentro del frame
        self.buttonLocal = tk.Button(self.button_frame, text="Ingresar a las opciones de local", command= self.abrir_local,  bg="indian red")
        self.buttonLocal.pack(side=tk.TOP, pady=10)

        self.buttonAdmin = tk.Button(self.button_frame, text="Ingresar a las opciones de administrador", command=self.abrir_admin,  bg="indian red") 
        self.buttonAdmin.pack(side=tk.TOP, pady=10) 

    def abrir_local(self):
        local = DesignLocal()
        local.mainloop()

    def abrir_admin(self):
        admin = Design()
        admin.mainloop()


if __name__ == "__main__":
    log = Login()
    log.mainloop()