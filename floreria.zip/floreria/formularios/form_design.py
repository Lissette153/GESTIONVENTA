import tkinter as tk
from tkinter import font
from config import COLOR_BARRA_SUPERIOR, COLOR_CUERPO_PRINCIPAL, COLOR_MENU_CURSOR, COLOR_MENU_LATERAL
import util.util_ventanas as util_ventana
import util.util_imagenes as util_img

class Design(tk.Tk):

    def __init__(self):
        super().__init__()
        self.logo = util_img.leer_imagen("./imagenes/flor.jpg", (560, 136))
        self.config_window()
    

    def config_window(self):
        self.title('Panel Administrador')
        ##LOGO
        self.iconbitmap("./imagenes/flor.jpg")
        ##TAMAÑO VENTANA
        w, h = 1024,600
        util_ventana.centrar_ventana(self, w,h)
    
    def paneles(self):
        #PANELES CON BARRA SUPERIOR, MENU LATERLAL Y CUERPO PRINCIPAL
        self.barra_superior = tk.Frame(self, bg=COLOR_BARRA_SUPERIOR, height=50)
        #SECCION DE BARRA SUPERIOR
        self.barra_superior.pack(side=tk.TOP, fill='both')
        
        self.menu_lateral = tk.Frame(self, bg=COLOR_MENU_LATERAL, width=150)
        self.menu_lateral.pack(side=tk.LEFT, fill='both', expand=False)

        self.cuerpo_principal = tk.Frame(self, bg=COLOR_CUERPO_PRINCIPAL, width=150)
        self.cuerpo_principal.pack(side=tk.RIGHT, fill='both', expand=True)

    

