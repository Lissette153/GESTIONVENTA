import tkinter as tk

#Importar modulos de tkinter
from tkinter import * 
from tkinter import ttk as ttk
from tkinter import messagebox
from BD.modelo import Usuario as usuario 



    




##GENERAR FORMULARIO DE INGRESO DE PRODUCTOS, VISUALIZACION Y ELIMINACION Y MODIFICACION


##GENERAR FORMULARIO DE INGRESO DE VENTAS, VISUALIZACION Y ELIMINACION Y MODIFICACION





##PARA EL ULTIMO

#FORMULARIOUSUARIO
class FormularioUsuarios:
       
 def  Formulario():
   try:
        base= Tk()
        base.geometry("1200x300")
        base.title("Formulario de Ingreso de Usuarios")

        groupBox = LabelFrame(base, text=" Ingrese los datos del usuario", padx=5,pady=5)     
        groupBox.grid(row=0, column=0, padx=10, pady=10)
        #ID
        labelId = Label(groupBox, text="Rut: ",width=13, font=("arial,12")).grid(row=0, column=0)
        textBoxId = Entry(groupBox)
        textBoxId.grid(row=0, column=1)
        #NOMBRE
        labelNombre = Label(groupBox, text="Nombre: ",width=13, font=("arial,12")).grid(row=1, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=1, column=1)

        #EMAIL
        labelEmail = Label(groupBox, text="Email: ",width=13, font=("arial,12")).grid(row=2, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=2, column=1)

        #CONTRASEÑA 
        labelContraseña = Label(groupBox, text="Contraseña: ",width=13, font=("arial,12")).grid(row=3, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=3, column=1)

        #ROL
        labelRol = Label(groupBox, text="Rol: ",width=13, font=("arial,12")).grid(row=4, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=4, column=1)

        #PRIVILEGIOS
        labelPrivilegios= Label(groupBox, text="Privilegios: ",width=13, font=("arial,12")).grid(row=5, column=0)
        textBoxNombre = Entry(groupBox)
        textBoxNombre.grid(row=5, column=1)







        base.mainloop()

   except  ValueError as error:
            print("Error al mostrar la interfaz: {}".format(error))

 Formulario()

