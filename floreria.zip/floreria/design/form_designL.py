__package__ = 'design'


import tkinter as tk
from tkinter import ttk
from tkinter import font
from.config import COLOR_BARRA_SUPERIOR, COLOR_CUERPO_PRINCIPAL, COLOR_MENU_CURSOR, COLOR_MENU_LATERAL, COLOR_CURSOR_ENCIMA
import util.util_ventanas as util_ventana
from formularios.ventas import * 
from formularios.productos import *
from BD.crud import *
from BD.modelo import *

class DesignLocal(tk.Tk):
    def __init__(self):
        super().__init__()
        self.config_window()
        self.paneles()
        self.controles_barra_superior()
        self.controles_menu_lateral()
        self.controles_cuerpo()

    def config_window(self):
        self.title('Panel de Usuario Local')

        ##TAMAÑO VENTANA
        w, h = 1024,600
        util_ventana.centrar_ventana(self, w,h)
    
    def paneles(self):
        #PANELES CON BARRA SUPERIOR, MENU LATERLAL Y CUERPO PRINCIPAL
        self.barra_superior = tk.Frame(self, bg=COLOR_BARRA_SUPERIOR, height=50)
        #SECCION DE BARRA SUPERIOR
        self.barra_superior.pack(side=tk.TOP, fill='both')
        
        self.menu_lateral = tk.Frame(self, bg=COLOR_MENU_LATERAL, width=150)
        self.menu_lateral.pack(side=tk.LEFT, fill='both', expand=False)

        self.cuerpo_principal = tk.Frame(self, bg=COLOR_CUERPO_PRINCIPAL, width=150)
        self.cuerpo_principal.pack(side=tk.RIGHT, fill='both', expand=True)

    def controles_barra_superior(self):
        #CONFIG
        font_awesome = font.Font(family='FontAwesome', size=12)
        #TITULO
        self.Labeltitulo = tk.Label(self.barra_superior, text="Panel de Usuario Local Floreria La blanco")
        self.Labeltitulo.config(fg="#fff", font=("Roboto", 15), bg=COLOR_BARRA_SUPERIOR, pady=10, width=156)
        self.Labeltitulo.pack(side=tk.LEFT)

        #BOTON MENU LATERAL PARA DESPLEGAR PREVIAMENTE EL MENU
        self.buttonMenuLateral = tk.Button(self.barra_superior, text="\uf0c9", font=font_awesome, command=self.toggle_panel, bd=0, bg=COLOR_BARRA_SUPERIOR, fg="white")
        self.buttonMenuLateral.pack(side=tk.LEFT)

        #ETIQUETA DE CORREO
        self.labelTitulo = tk.Label(self.barra_superior, text="joisyda0512@gmail.com")
        self.labelTitulo.config(fg="#fff", font=("Roboto", 10), bg=COLOR_BARRA_SUPERIOR, padx=10, width=20)
        self.labelTitulo.pack(side=tk.RIGHT)

    def controles_menu_lateral(self):
        # Configuración del menú lateral
        ancho_menu = 20
        alto_menu = 2
        font_awesome = font.Font(family='FontAwesome', size=15)
         
         # Etiqueta de perfil
        self.labelPerfil = tk.Label(
            self.menu_lateral,  bg=COLOR_MENU_LATERAL)
        self.labelPerfil.pack(side=tk.TOP, pady=10)


        # Botones del menú lateral
        
        self.buttonProfile = tk.Button(self.menu_lateral)
        self.buttonP = tk.Button(self.menu_lateral, command= self.panel_producto)  
        self.buttonV = tk.Button(self.menu_lateral, command= self.panel_venta)
        self.buttonG = tk.Button(self.menu_lateral, command= self.panel_gasto)
        self.buttonPres= tk.Button(self.menu_lateral, command= self.panel_presupuesto) 
        self.buttonLogOut = tk.Button(self.menu_lateral, command=self.volver_al_inicio)

        buttons_info = [
            ("Profile", "\uf007", self.buttonProfile),
            ("Productos", "\uf02c", self.buttonP),
            ("Ventas", "\uf09d", self.buttonV),
            ("Gastos", "\uf0f0", self.buttonG),
            ("Revisar el Presupuesto", "\uf0f0", self.buttonPres),
            ("Log Out", "\uf013", self.buttonLogOut)
        ]

        for text, icon, button in buttons_info:
            self.configurar_boton_menu(button, text, icon, font_awesome, ancho_menu, alto_menu)
            button.pack(side=tk.TOP)

    def panel_producto(self):
        VentanaProductos()

    def panel_venta(self):
        VentanaVentas()

    def panel_gasto(self):
        pass
    
    def panel_presupuesto(self):
        pass

    def controles_cuerpo(self):
        #COLOR CUERPO PRINCIPAL
        label = tk.Label(self.cuerpo_principal, bg= COLOR_CUERPO_PRINCIPAL)
        label.place(x=0, y=0, relwidth=1, relheight=1)

    def configurar_boton_menu(self, button, text,icon, font_awesome, ancho_menu, alto_menu):
        button.config(text=f" {icon}  {text}", anchor="w", font=font_awesome,
                      bd=0, bg=COLOR_MENU_LATERAL, fg="white", width=ancho_menu, height=alto_menu)
        button.pack(side=tk.TOP)
        self.bind_hover_events(button)
    
    def bind_hover_events(self, button):
        # Asociar eventos Enter y Leave con la función dinámica
        button.bind("<Enter>", lambda event: self.on_enter(event, button))
        button.bind("<Leave>", lambda event: self.on_leave(event, button))

    
    def on_enter(self, event, button):
        # Cambiar estilo al pasar el ratón por encima
        button.config(bg=COLOR_CURSOR_ENCIMA, fg='white')

    def on_leave(self, event, button):
        # Restaurar estilo al salir el ratón
        button.config(bg=COLOR_MENU_LATERAL, fg='white')

    def toggle_panel(self):
        # Alternar visibilidad del menú lateral
        if self.menu_lateral.winfo_ismapped():
            self.menu_lateral.pack_forget()
        else:
            self.menu_lateral.pack(side=tk.LEFT, fill='y')


    def volver_al_inicio(self):
        self.destroy()