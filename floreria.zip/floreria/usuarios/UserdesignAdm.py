import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from tkinter import font
from tkinter import *
from design.config import COLOR_BARRA_SUPERIOR
import util.util_ventanas as util_ventana
from BD.crud import *
from BD.modelo import *

class UserDesign(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry("300x200")
        self.title("Botones Design")
        self.botones()
        self.control_barra_superior()

    def botones(self):
        w, h = 1024,600
        util_ventana.centrar_ventana(self, w,h)
        self.barra_superior = tk.Frame(self, bg=COLOR_BARRA_SUPERIOR, height=50)
        self.barra_superior.pack(side=tk.TOP, fill='both')

        self.crud_usuario = CrudUsuario()

        frame_lista_usuarios =  ttk.Treeview(self)
        frame_lista_usuarios.pack(pady=10)

        # Lista de usuarios
        self.lista_usuarios = ttk.Treeview(frame_lista_usuarios, columns=("rut","nombre", "rol", "privilegios", "email"), show="headings")
        self.lista_usuarios.heading("rut", text="RUT DEL USUARIO")
        self.lista_usuarios.heading("nombre", text="Nombre")
        self.lista_usuarios.heading("rol", text="Rol")
        self.lista_usuarios.heading("privilegios", text="Privilegios")
        self.lista_usuarios.heading("email", text="Email")
        self.lista_usuarios.pack()

        # Botón para actualizar la lista
        boton_modificar = tk.Button(self, text="Modificar")
        boton_modificar.pack(pady=10)

        # Botón para agregar un nuevo producto
        boton_agregar = tk.Button(self, text="Agregar Usuario")
        boton_agregar.pack(pady=10)

        # Botón para eliminar un producto
        boton_eliminar = tk.Button(self, text="Eliminar Usuario", )
        boton_eliminar.pack(pady=10)

        boton_actualizar = tk.Button(self, text="Actualizar la lista de Usuario")
        boton_actualizar.pack(pady=10)
        self.actualizar_lista_usuarios()

    def actualizar_lista_usuarios(self):
        self.lista_usuarios.delete(*self.lista_usuarios.get_children())
        usuarios = self.crud_usuario.obtener_usuarios()

        for usuario in usuarios:
            self.lista_usuarios.insert("", tk.END, values=(usuario.obtener_rut(), usuario.obtener_nombre(), usuario.obtener_rol(), usuario.obtener_privilegio(), usuario.obtener_email()))


    def control_barra_superior(self):
        font_awesome = font.Font(family='FontAwesome', size=12)
        #TITULO
        self.Labeltitulo = tk.Label(self.barra_superior, text="Panel Administrador Floreria La blanco")
        self.Labeltitulo.config(fg="#fff", font=("Roboto", 15), bg=COLOR_BARRA_SUPERIOR, pady=10, width=156)
        self.Labeltitulo.pack(side=tk.LEFT)
        
        self.labelTitulo = tk.Label(self.barra_superior, text="joisyda0512@gmail.com")
        self.labelTitulo.config(fg="#fff", font=("Roboto", 10), bg=COLOR_BARRA_SUPERIOR, padx=10, width=20)
        self.labelTitulo.pack(side=tk.RIGHT)

    

    