
create database floreria_db;
use floreria_db;
---Producto
create table if not exists producto(
    id_producto int primary key,
    nombre varchar(35) not null,
    precio numeric(10) not null,
    descripcion varchar(100),
    categoria varchar(25) not null,
    stock int not null
)
---presupuesto

create table if not exists presupuesto(
    id_presupuesto int primary key,
    calculo_total numeric(10) not null
)

--Venta
create table if not exists venta(
    id_venta int primary key,
    fecha date not null,
    total numeric(10) not null,
    estado_pago BOOLEAN not null,
    descripcion varchar(50),
    ##CANTIDAD
    id_presupuesto int,
    FOREIGN KEY (id_presupuesto) REFERENCES presupuesto(id_presupuesto)
)

alter table venta add column cantidad int; 
alter table venta ADD COLUMN id_venta int PRIMARY key auto_increment;

alter table producto ADD COLUMN id_producto int PRIMARY key auto_increment;

alter table gasto ADD COLUMN id_gasto int PRIMARY key auto_increment;
--Gasto
create  table if NOT exists gasto(
    id_gasto int primary key,
    descripcion varchar(100) not null,
    tipo varchar(50) not null,
    monto numeric(10) not null,
    fecha date not null,
    id_presupuesto INT,
    FOREIGN KEY (id_presupuesto) REFERENCES presupuesto(id_presupuesto)
)

--Item
create table if NOT exists item(
    cantidad numeric(10),
    id_venta int,
    id_producto int,
    PRIMARY KEY (id_venta, id_producto),
    FOREIGN KEY (id_venta) REFERENCES venta(id_venta),
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto)
)

--Usuario
create table if NOT exists usuario(
    rut int primary key,
    nombre varchar(20) not null,
    contraseña varchar(15) not null,
    privilegios varchar(100) not null,
    rol varchar(20) not null,
    email varchar(50),
    id_producto int,
    id_venta int,
    id_gasto int,
    id_presupuesto INT,
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
    FOREIGN KEY (id_venta) REFERENCES venta(id_venta),
    FOREIGN KEY (id_gasto) REFERENCES gasto(id_gasto),
    FOREIGN KEY (id_presupuesto) REFERENCES presupuesto(id_presupuesto)
)
