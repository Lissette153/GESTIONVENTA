
create database floreria_db;
use floreria_db;
---Producto
create table if not exists producto(
    id_producto int primary key AUTO_INCREMENT,
    nombre varchar(35) not null,
    precio numeric(10) not null,
    descripcion varchar(100),
    categoria varchar(25) not null,
    stock int not null
)
---presupuesto

create table if not exists presupuesto(
    id_presupuesto int primary key AUTO_INCREMENT,
    calculo_total numeric(10) not null
)

--Venta
create table if not exists venta(
    id_venta int primary key AUTO_INCREMENT,
    fecha date not null,
    total numeric(10) not null,
    estado_pago BOOLEAN not null,
    descripcion varchar(50),
    cantidad int,
    FOREIGN KEY (id_presupuesto) REFERENCES presupuesto(id_presupuesto)
)


--Gasto
create  table if NOT exists gasto(
    id_gasto int primary key AUTO_INCREMENT,
    descripcion varchar(100) not null,
    tipo varchar(50) not null,
    monto numeric(10) not null,
    fecha_gasto date not null
)



--Usuario
create table if NOT exists usuario(
    rut int primary key,
    nombre varchar(20) not null,
    contraseña varchar(15) not null,
    privilegios varchar(100) not null,
    rol varchar(20) not null,
    email varchar(50),
    id_producto int,
    id_venta int,
    id_gasto int,
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
    FOREIGN KEY (id_venta) REFERENCES venta(id_venta),
    FOREIGN KEY (id_gasto) REFERENCES gasto(id_gasto),
)
