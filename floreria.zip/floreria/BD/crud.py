import mysql.connector
import hashlib
from BD.modelo import Producto, Venta, Gasto, Presupuesto, Item, Usuario

import mysql.connector
import hashlib

class CrudUsuario:
    """"
    Clase que permite realizar operaciones CRUD sobre la tabla usuario de la base de datos.
    """         
    def __init__(self):
        """DENTRO DEL _INIT_ SE DECLARA LA CONEXIÓN DE BASE DE DATOS DE USUARIO.

        Returns: 
            :param usuario: Usuario de la base de datos ('root')
            :param contraseña: Contraseña de la base de datos ('')
            :param host: Dirección del servidor de la base de datos('localhost')
            :param base_de_datos: Nombre de la base de datos ('floreria_db')
            :return: Conexión a la base de datos.
        """
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )

    def crear_usuario(self, rut, nombre, contraseña, rol, privilegios, email):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de creación de usuario llamando a la base de datos, sus atributos y la agregación de atributos dentro de 
        la tabla con el metodo Insert into.

        Establecemos filas para cada atributo agregado con un contador.

        Args:
            rut (_INT_): ID de la tabla de usuario que se ingresa de forma manúal.
            nombre (_VARCHAR_): Nombre del usuario a ingresar.
            contraseña (_VARCHAR_):  Contraseña del usuario a ingresar.
            rol (_VARCHAR_): Rol del usuario a ingresar.
            privilegios (_VARCHAR_): Privilegios del usuario a ingresar
            email (_VARCHAR_): Email del usuario a ingresar.

        Returns:
            Ingreso de los siguientes atributos hacia la tabla de usuario. (con un formulario previo)
            obtener_rut : ID
            obtener_nombre : VARCHAR
            obtener_contraseña : VARCHAR
            obtener_rol : VARCHAR
            obtener_privilegios : VARCHAR 
            obtener_email: VARCHAR
        """
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO usuario (rut, nombre, contraseña, rol, privilegios, email) VALUES (%s, %s, %s, %s, %s, %s)'
        val = (rut.obtener_rut(), nombre.obtener_nombre(), contraseña.obtener_contraseña(), rol.obtener_rol(), privilegios.obtener_privilegio(), email.obtener_email())
        cursor.execute(sql, val)

        n_filas = cursor.rowcount
        self.conexion.commit()
        cursor.close()
        return n_filas > 0
    
    def obtener_usuarios(self):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de listar 
        cada usuario gracias a la base de datos creada de la tabla usuario, mostrando cada
        atributo creado y agregado anteriormente, mostrandolos con el metodo Select * from Usuario. Donde también establecemos
        una lista de usuarios.

        Returns:
            Usuario(Cada columna de la tabla, se devolvera):
            rut: row[0] 
            nombre: row[1]
            rol:  row[3]
            privilegios: row[4]
            email: row[5]
        """
        usuarios = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM usuario'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            user = Usuario(rut=row[0], nombre=row[1], rol=row[3], privilegios=row[4], email=row[5])
            usuarios.append(user)
        cursor.close()
        return usuarios
            
    def buscar_usuario(self,rut):
        """Estableciendo una conexión con la base de datos (self.conexion.cursor), generamos una función de busqueda de usuario
        a traves de la selección de este por su Rut respectivo. Lo cual nos permitirá mostrar los datos del usuario seleccionado.
        Con el metodo: SELECT * FROM USUARIO WHERE RUT=%S

        Args:
            rut (INT): ID de la tabla de usuario que nos permite filtrar la busqueda de un usuario.
        Si la busqueda coincide con la ID: (if)
        Returns:
           Usuario(Cada columna de la tabla, se devolvera según su busqueda):
           rut: row[0]
           nombre: row[1]
           rol:  row[3]
           privilegios: row[4]
           email: row[5]
        
        Raises:
           else: Exception ('RETURN NONE')
        """
        cursor = self.conexion.cursor()
        sql = 'select * from usuario where rut = %s'
        val = (rut,)
        cursor.execute(sql, val)
        result = cursor.fetchone()
        if result is None:
            return None
        else:
            us = Usuario( rut = result[0],nombre=result[1], privilegios= result[2], rol= result[3], email = result[4])
            return us

    def modificar_usuario(self, rut, usuario):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de usuario
        a traves de la selección de este por su Rut respectivo, la cual nos permitira modificar los atributos de la tabla de usuario.
        Con el metodo: UPDATE USUARIO SET (ATRIBUTOS/DATOS) WHERE RUT= %S 

        Args:
            rut (INT): ID de la tabla de usuario que nos permite filtrar la busqueda de un usuario (y modificar el usuario deseado).
            usuario(selección): Dentro de la visualización de la tabla de usuarios se podra elegir un usuario deseado a modificar.

        Si la busqueda coincide con la ID: (if)
        Returns:
           Usuario(Cada columna de la tabla, se devolvera según su busqueda y se podrá modificar):
           rut: row[0]
           nombre: row[1]
           rol:  row[3]
           privilegios: row[4]
           email: row[5]
        """
        cursor = self.conexion.cursor()
        sql = 'UPDATE usuario SET nombre = %s, contraseña = %s, rol = %s, privilegios = %s, email = %s WHERE rut = %s'
        val = (usuario.obtener_nombre(), usuario.obtener_rol(), usuario.obtener_privilegio(), usuario.obtener_email(), rut)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()

    def eliminar_usuario(self, rut):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de usuario
        a traves de la selección de este por su Rut respectivo, la cual nos permitirá eliminar a un usuario deseado.
        Con el METODO:  DELETE FROM USUARIO WHERE RUT = %S

        Args:
            rut (ID): ID de la tabla de usuario que nos permite filtrar la busqueda de un usuario( y eliminar el usuario deseado).
            usuario(selección): Dentro de la visualización de la tabla de usuarios se podra elegir un usuario deseado a eliminar.
         
        Si la busqueda coincide con la ID: (if)
        Returns:
            usuario: Confirmación de eliminación de usuario.
            usuario: Eliminación.
        
        Raises:
           else: Exception ('Error')
        """
        cursor = self.conexion.cursor()
        try:
    
            sql = 'DELETE FROM usuario WHERE rut = %s'
            cursor.execute(sql, (rut,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el cliente: {e}')
        finally:
            cursor.close()

class CrudProducto:
    """"
    Clase que permite realizar operaciones CRUD sobre la tabla producto de la base de datos.
    """
    def __init__(self):
        """DENTRO DEL _INIT_ SE DECLARA LA CONEXIÓN DE BASE DE DATOS DE PRODUCTO

        Returns: 
            :param usuario: Usuario de la base de datos ('root')
            :param contraseña: Contraseña de la base de datos ('')
            :param host: Dirección del servidor de la base de datos('localhost')
            :param base_de_datos: Nombre de la base de datos ('floreria_db')
            :return: Conexión a la base de datos.
        """
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def agregar_producto(self, nombre, precio, descripcion, categoria, stock):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de creación de productos llamando a la base de datos,
        sus atributos y la agregación de atributos dentro de 
        la tabla con el metodo Insert into.

        Establecemos filas para cada atributo agregado con un contador.

        Args:
            ID (SE GENERA DE FORMA AUTÓMATICA) CON LASTROWID
            nombre (_VARCHAR_): Nombre del producto a ingresar.
            precio (_NUMERIC_):  Precio del producto a ingresar.
            descripcion (_VARCHAR_): Descripción del producto a ingresar.
            categoria (_VARCHAR_):  Categoria del producto a ingresar
            stock (_INT_): Stock del producto a ingresar. (Nos permitira mantener un manejo de inventario)
        """
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO producto (nombre, precio, descripcion, categoria, stock) VALUES (%s, %s, %s, %s,%s)'
        val = (nombre, precio, descripcion, categoria, stock)
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
    
    def buscar_producto(self, id_producto):
        """Estableciendo una conexión con la base de datos (self.conexion.cursor), generamos una función de busqueda de productos
        a traves de la selección de este por su ID respectivo. Lo cual nos permitirá mostrar los datos del usuario seleccionado.
        Con el metodo: SELECT * FROM PRODUCTO WHERE ID_PRODUCTO=%S

        Args:
            ID_PRODUCTO (INT): ID de la tabla de producto que nos permite filtrar la busqueda de este.
        Si la busqueda coincide con la ID: (if)
        Returns:
           Producto(Cada columna de la tabla, se devolvera según su busqueda):
           id_producto: row[5]
           nombre: row[0]
           precio: row[1]
           descripción: row[2]
           categoria: row[3]
           stock: row[4]
        Raises:
           else: Exception ('Return NONE')
        """
        cursor = self.conexion.cursor()
        sql = 'select * from producto where id_producto = %s'
        val = (id_producto,)
        cursor.execute(sql, val)
        result = cursor.fetchone()
        if result is None:
            return None
        else:
            prod = Producto( nombre=result[0], precio= result[1], descripcion=result[2], categoria=result[3], stock=result[4], id_producto=result[5])
            return prod
        
    def obtener_productos(self):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de listar 
        cada producto gracias a la base de datos creada, mostrando cada atributo creado y agregado anteriormente.
        Con el metodo Select * from Producto. Donde también establecemos
        una lista de productos

        Returns:
            Productos (Cada columna de la tabla, se devolvera):
            id: row[5] 
            nombre: row[0]
            precio:  row[1]
            descripcion: row[2]
            categoria: row[3]
            stock: row[4]
        """
        productos = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM producto '
        cursor.execute(sql,)
        result = cursor.fetchall()
        for row in result:
            producto = Producto(
                row[5], #ID
                row[0], #NOMBRe
                row[1], #PRECIO
                row[2], #DESCRIPCION
                row[3], #CATEGORIA
                row[4] #STOCK
            )
            productos.append(producto)
        cursor.close()
        return productos
    
    def obtener_id_producto(self):
        """Estableciendo una conexión con la base de datos (self.conexion.cursor), generamos una función que es para obtener la id del producto,
        gracias a la base de datos creada(PARA QUE SE PUEDA GENERAR DE FORMA AUTOMATICA)
        Con el metodo: SELECT LAST_INSERT_ID()
        Returns:
            ID: La id es de tipo int y devuelve la ultima id agregada hacia la tabla de productos.
        """
        cursor = self.conexion.cursor()
        cursor.execute("SELECT LAST_INSERT_ID()")
        id_producto = cursor.fetchone()[5]
        cursor.close()
        return id_producto
    
    def modificar_producto(self, nombre, precio, stock, id_producto):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de producto
        a traves de la selección de este por su ID respectivo, la cual nos permitira modificar los atributos de la tabla de productos.
        Con el metodo: UPDATE PRODUCTO SET(ATRIBUTOS/DATOS) WHERE ID_PRODUCTO =  %S 

        Args:
            ID_PRODUCTO (INT): ID de la tabla de producto que nos permite filtrar la busqueda ( y modificar el producto deseado).
            PRODUCTO(selección): Dentro de la visualización de la tabla de producto se podra elegir el deseado a modificar.

        Si la busqueda coincide con la ID: (if)
        Returns:
           Producto(Cada columna de la tabla, se devolvera según su busqueda y se podrá modificar):
           nombre: row[0]
           precio: row[1]
           stock: row[4]
        """
        print(f"Modificando producto: id={id_producto}, nombre={nombre}, precio={precio}, stock={stock}")
        cursor = self.conexion.cursor()
        sql = 'UPDATE producto SET nombre = %s, precio = %s, stock = %s WHERE id_producto = %s'
        cursor.execute(sql, (nombre, precio, stock, id_producto))
        self.conexion.commit()
        cursor.close()
    
    def eliminar_producto(self, id_producto):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de producto
        a traves de la selección de este por su ID respectivo, la cual nos permitirá eliminar a un producto deseado.
        Con el METODO:  DELETE FROM PRODUCTO WHERE ID_PRODUCTO = %S

        Args:
            ID_PRODUCTO (ID: INT): ID de la tabla de producto que nos permite filtrar la busqueda( y eliminar el producto deseado).
            PRODUCTO(selección): Dentro de la visualización de la tabla de productos se podra elegir el deseado a eliminar.
         
        Si la busqueda coincide con la ID: (if)
        Returns:
            Producto: Confirmación de eliminación de producto.
            Producto: Eliminación.
        
        Raises:
           else: Exception ('Error')
        """
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM producto WHERE id_producto = %s'
            cursor.execute(sql, (id_producto,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el producto: {e}')
        finally:
            cursor.close()

class CrudVenta:
    """"
    Clase que permite realizar operaciones CRUD sobre la tabla venta de la base de datos.
    """   
    def __init__(self):
        """DENTRO DEL _INIT_ SE DECLARA LA CONEXIÓN DE BASE DE DATOS DE VENTAS.

        Returns: 
            :param usuario: Usuario de la base de datos ('root')
            :param contraseña: Contraseña de la base de datos ('')
            :param host: Dirección del servidor de la base de datos('localhost')
            :param base_de_datos: Nombre de la base de datos ('floreria_db')
            :return: Conexión a la base de datos.
        """
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def agregar_venta(self, fecha, total, estado_pago, descripcion, cantidad):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de creación de venta
         llamando a la base de datos, sus atributos y la agregación de estos dentro de 
        la tabla con el metodo Insert into.

        Establecemos filas para cada atributo agregado con un contador.
        AGREGAMOS LOS SIGUIENTES ATRIBUTOS A TRAVES DE UN FORMULARIO: 
        Args:
            id_venta (int) (SE GENERA EL ID DE FORMA AUTÓMATICA GRACIAS A LASTROWID)
            fecha (_DATE_): Fecha de la venta a ingresar.
            total (_NUMERIC_): Total de la venta ingresar.
            estado_pago (_BOOLEAN_): Estado de pago de la venta a ingresar.
            descripcion (_VARCHAR_): Descripción de la venta a ingresar.
            cantidad (_INT_): Cantidad  de la venta a ingresar
        """
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO venta (fecha, total, estado_pago, descripcion, cantidad) VALUES (%s, %s, %s, %s,%s)'
        val = (fecha, total, estado_pago, descripcion, cantidad )
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id

    def obtener_venta(self):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de listar 
        cada venta gracias a la base de datos creada, mostrando cada atributo creado y agregado anteriormente.
        Con el metodo Select * from Venta, donde también establecemos una lista de ventas 

        Returns:
            Venta (Cada columna de la tabla, se devolvera):
            id: row[5] (SE GENERA EL ID DE FORMA AUTÓMATICA)
            fecha: row[0]
            total: row[1]
            estado_pago: row[2] (SE ESTABLECERA UN IF SI ES: 0: "PAGADO" Y SI ES 1: "NO PAGADO")
            descripcion: row[3]
            cantidad: row[4]
        """
        ventas = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM venta'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            venta = Venta(
                row[5],  #id_venta
                row[0], #fecha
                row[1], #total
                "No Pagado" if row[2] == 1 else "Pagado" if row[2] == 0 else "Estado de pago no declarado",  # estado_pago
                row[3], #descripcion
                row[6]  #cantidad
            )
            ventas.append(venta)
        cursor.close()
        return ventas
    
    def eliminar_venta(self, id_venta):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de Ventas
        a traves de la selección de este por su ID respectivo, la cual nos permitirá eliminar a una venta deseada.
        Con el METODO:  DELETE FROM  VENTA WHERE ID_VENTA= %S

        Args:
            ID_VENTA (ID: INT): ID de la tabla de  venta que nos permite filtrar la busqueda( y eliminar la venta deseado).
            VENTA(selección): Dentro de la visualización de la tabla de venta se podra elegir el deseado a eliminar.
         
        Si la busqueda coincide con la ID: (if)
        Returns:
            Venta: Confirmación de eliminación de la venta.
            Venta: Eliminación.
        
        Raises:
           else: Exception ('Error')
        """
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM venta WHERE id_venta = %s'
            cursor.execute(sql, (id_venta,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar la venta: {e}')
        finally:
            cursor.close()

    def calcular_monto_total_ventas(self, fecha):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de Ventas
        a traves de la selección de este por su fecha respectiva ingresada en un motor de busqueda, la cual si existe nos permite
        sumar los montos de otras ventas (en caso de que sea solo 1 venta se muestra el monto de una sola)
        Con el METODO:  SELECT * FROM VENTA WHERE fecha = %S Y  sum(venta['total'] for venta in ventas
       
        Args:
            fecha (_date_): Se realiza la busqueda de la fecha de la venta.
            ventas (list): Se suma el monto(atributo:"total") entre estas ventas que estan asociadas a una fecha.
        

        Returns:
            if total_ventas > 0: return ventas, total_ventas.
        
        Raises:
           else: Exception ('Error')
        """
        cursor = self.conexion.cursor(dictionary=True)
        sql = 'SELECT * FROM venta WHERE fecha = %s'
        cursor.execute(sql, (fecha,))
        ventas = cursor.fetchall()
        cursor.close()
        total_ventas = sum(venta['total'] for venta in ventas)
        if total_ventas > 0:
            return ventas, total_ventas
        else:
            raise Exception("Error: Cálculo no realizado o no hay ventas para esa fecha")

class CrudGasto:
    """"
    Clase que permite realizar operaciones CRUD sobre la tabla gastos de la base de datos.
    """
    def __init__(self):
        """DENTRO DEL _INIT_ SE DECLARA LA CONEXIÓN DE BASE DE DATOS DE GASTO

        Returns: 
            :param usuario: Usuario de la base de datos ('root')
            :param contraseña: Contraseña de la base de datos ('')
            :param host: Dirección del servidor de la base de datos('localhost')
            :param base_de_datos: Nombre de la base de datos ('floreria_db')
            :return: Conexión a la base de datos.
        """
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def agregar_gasto(self, descripcion, tipo, monto, fecha_gasto):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de creación de gastos
        llamando a la base de datos, sus atributos y la agregación dentro de la tabla con el metodo Insert into.

        Establecemos filas para cada atributo agregado con un contador.

        Args:
            ID (SE GENERA DE FORMA AUTÓMATICA) CON LASTROWID
            descripción (_VARCHAR_): Descripción del gasto a ingresar.
            tipo (_VARCHAR_):  Tipo del gasto a ingresar.
            monto (_NUMERIC_): Monto del gasto a ingresar.
            fecha (_DATE_):  Fecha del gasto a ingresar
        """
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO gasto (descripcion, tipo, monto, fecha_gasto) VALUES (%s, %s, %s, %s)'
        val = (descripcion, tipo, monto, fecha_gasto)
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
    
    def obtener_gasto(self):
        """Estableciendo la conexión con la base de datos (self.conexion.cursor()), generamos la función de listar 
        cada gasto gracias a la base de datos creada, mostrando cada atributo creado y agregado anteriormente.
        Con el metodo Select * from GASTO. Donde también establecemos
        una lista de gastos

        Returns:
            Gastos (Cada columna de la tabla, se devolvera):
            id: row[0] 
            descripcion: row[1]
            tipo: row[2]
            monto: row[3]
            fecha: row[4]
        """
        gastos = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM gasto'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            gasto = Gasto(
                row[0],  #id_gasto
                row[1], #descripcion
                row[2], #tipo
                row[3], #monto
                row[4] #fecha
            )
            gastos.append(gasto)
        cursor.close()
        return gastos
    
    def modificar_gasto(self, id_gasto, gasto):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de gasto
        a traves de la selección de este por su ID respectivo, la cual nos permitira modificar los atributos de la tabla de gastos.
        Con el metodo: UPDATE GASTO SET(ATRIBUTOS/DATOS) WHERE ID_GASTO=  %S 

        Args:
            ID_GASTO (INT): ID de la tabla de gasto que nos permite filtrar la busqueda ( y modificar el gasto deseado).
            GASTO(selección): Dentro de la visualización de la tabla de gasto se podra elegir el deseado a modificar.

        Si la busqueda coincide con la ID: (if)
        Returns:
           GASTO(Cada columna de la tabla, se devolvera según su busqueda y se podrá modificar):
           descripcion (VARCHAR),
           tipo (VARCHAR),
           fecha (DATE),
           monto (NUMERIC)
        """
        cursor = self.conexion.cursor()
        sql = 'UPDATE gasto SET descripcion = %s, tipo = %s, fecha_gasto = %s, monto = %s WHERE id_gasto = %s'
        val = (gasto.obtener_descripcion(), gasto.obtener_tipo(), gasto.obtener_fecha(), gasto.obtener_monto(), id_gasto)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()

    def eliminar_gasto(self, id_gasto):
        """Estableciendo una conexión con la base de datos(self.conexion.cursor), generamos una función de busqueda de 
        a traves de la selección de este por su ID respectivo, la cual nos permitirá eliminar a un gasto deseado.
        Con el METODO:  DELETE FROM GASTO WHERE ID_GASTO = %S

        Args:
            ID_GASTO (ID: INT): ID de la tabla de gasto que nos permite filtrar la busqueda( y eliminar el gasto deseado).
            GASTO(selección): Dentro de la visualización de la tabla de gastos se podra elegir el deseado a eliminar.
         
        Si la busqueda coincide con la ID: (if)
        Returns:
            Gasto: Confirmación de eliminación de gasto.
            Gasto: Eliminación.
        
        Raises:
           else: Exception ('Error')
        """
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM gasto WHERE id_gasto = %s'
            cursor.execute(sql, (id_gasto,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el gasto: {e}')
        finally:
            cursor.close()




