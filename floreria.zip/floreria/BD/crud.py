import mysql.connector
import hashlib
from BD.modelo import Producto, Venta, Gasto, Presupuesto, Item, Usuario

import mysql.connector
import hashlib

class CrudUsuario:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )

##FUNCION DE CREACION USUARIO
    def crear_usuario(self, rut, nombre, contraseña, rol, privilegios, email):
        hash_contraseña = hashlib.md5(contraseña.encode()).hexdigest()
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO usuario (rut, nombre, contraseña, rol, privilegios, email) VALUES (%s, %s, %s, %s, %s, %s)'
        val = (rut.obtener_rut(), nombre.obtener_nombre(), hash_contraseña, rol.obtener_rol(), privilegios.obtener_privilegio(), email.obtener_email())
        cursor.execute(sql, val)

        n_filas = cursor.rowcount
        self.conexion.commit()
        cursor.close()
        return n_filas > 0
    
##FUNCION DE LISTAR USUARIO
    def obtener_usuarios(self):
        usuarios = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM usuario'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            user = Usuario(rut=row[0], nombre=row[1], rol=row[3], privilegios=row[4], email=row[5])
            usuarios.append(user)
        cursor.close()
        return usuarios

    def login(self, email, contraseña):
        cursor = self.conexion.cursor()
        if email != None:
            sql = 'select * from usuario where email = %s'
            hash_contraseña = hashlib.md5(contraseña.encode()).hexdigest()
            

##BUSCAR USUARIO
    def buscar_usuario(self,rut):
        cursor = self.conexion.cursor()
        sql = 'select * from usuario where rut = %s'
        val = (rut,)
        cursor.execute(sql, val)
        result = cursor.fetchone()
        if result is None:
            return None
        else:
            us = Usuario( rut = result[0],nombre=result[1], privilegios= result[2], rol= result[3], email = result[4])
            return us

##FUNCION DE MODIFICAR USUARIO    
    def modificar_usuario(self, rut, usuario):
        cursor = self.conexion.cursor()
        sql = 'UPDATE usuario SET nombre = %s, rol = %s, privilegios = %s, email = %s WHERE rut = %s'
        val = (usuario.obtener_nombre(), usuario.obtener_rol(), usuario.obtener_privilegio(), usuario.obtener_email(), rut)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()
    
##MODIFICAR CONTRASEÑA
    def modificar_contraseña(self, rut, nueva_contraseña):
        hash_contraseña = hashlib.md5(nueva_contraseña.encode()).hexdigest()
        cursor = self.conexion.cursor()
        sql = 'UPDATE usuario SET contraseña = %s WHERE rut = %s'
        val = (hash_contraseña, rut)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()
    
##ELIMINAR USUARIO
    def eliminar_usuario(self, rut):
        cursor = self.conexion.cursor()
        try:
    
            sql = 'DELETE FROM usuario WHERE rut = %s'
            cursor.execute(sql, (rut,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el cliente: {e}')
        finally:
            cursor.close()



class CrudProducto:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
##AGREGAR PRODUCTO
    def agregar_producto(self, nombre, precio, descripcion, categoria, stock):
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO producto (nombre, precio, descripcion, categoria, stock) VALUES (%s, %s, %s, %s,%s)'
        val = (nombre, precio, descripcion, categoria, stock)
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
        

##BUSCAR PRODUCTO
    def buscar_producto(self, id_producto):
        cursor = self.conexion.cursor()
        sql = 'select * from producto where id_producto = %s'
        val = (id_producto,)
        cursor.execute(sql, val)
        result = cursor.fetchone()
        if result is None:
            return None
        else:
            prod = Producto( nombre=result[0], precio= result[1], descripcion=result[2], categoria=result[3], stock=result[4], id_producto=result[5])
            return prod
        

##LISTAR PRODUCTOS
    def obtener_productos(self):
        productos = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM producto '
        cursor.execute(sql,)
        result = cursor.fetchall()
        for row in result:
            producto = Producto(
                row[5],
                row[0],
                row[1],
                row[2],
                row[3],
                row[4]
            )
            productos.append(producto)
        cursor.close()
        return productos
    

    def obtener_id_producto(self):
       
        cursor = self.conexion.cursor()

        cursor.execute("SELECT LAST_INSERT_ID()")
        id_producto = cursor.fetchone()[5]
        cursor.close()
        return id_producto
    
##MODIFICAR PRODUCTO
    def modificar_producto(self, nombre, precio, stock, id_producto):
        print(f"Modificando producto: id={id_producto}, nombre={nombre}, precio={precio}, stock={stock}")
        cursor = self.conexion.cursor()
        sql = 'UPDATE producto SET nombre = %s, precio = %s, stock = %s WHERE id_producto = %s'
        cursor.execute(sql, (nombre, precio, stock, id_producto))
        self.conexion.commit()
        cursor.close()
    
##ELIMINAR PRODUCTO
    def eliminar_producto(self, id_producto):
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM producto WHERE id_producto = %s'
            cursor.execute(sql, (id_producto,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el producto: {e}')
        finally:
            cursor.close()


class CrudVenta:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
##AGREGAR VENTA
    def agregar_venta(self, fecha, total, estado_pago, descripcion, cantidad):
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO venta (fecha, total, estado_pago, descripcion, cantidad) VALUES (%s, %s, %s, %s,%s)'
        val = (fecha, total, estado_pago, descripcion, cantidad )
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
    
##LISTAR VENTA
    def obtener_venta(self):
        ventas = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM venta'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            venta = Venta(
                row[5],  #id_venta
                row[0], #fecha
                row[1], #total
                "No Pagado" if row[2] == 1 else "Pagado" if row[2] == 0 else "Estado de pago no declarado",  # estado_pago
                row[3], #descripcion
                row[6]  #cantidad
            )
            ventas.append(venta)
        cursor.close()
        return ventas
      
    def eliminar_venta(self, id_venta):
        cursor = self.conexion.cursor()
        try:
    
            sql = 'DELETE FROM venta WHERE id_venta = %s'
            cursor.execute(sql, (id_venta,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar la venta: {e}')
        finally:
            cursor.close()

    def calcular_monto_total_ventas(self, fecha):
        cursor = self.conexion.cursor(dictionary=True)
        sql = 'SELECT * FROM venta WHERE fecha = %s'
        cursor.execute(sql, (fecha,))
        ventas = cursor.fetchall()
        cursor.close()
        total_ventas = sum(venta['total'] for venta in ventas)
        if total_ventas > 0:
            return ventas, total_ventas
        else:
            raise Exception("Error: Cálculo no realizado o no hay ventas para esa fecha")
        

class CrudGasto:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )
    
    def agregar_gasto(self, descripcion, tipo, monto, fecha_gasto):
        cursor = self.conexion.cursor()
        sql = 'INSERT INTO gasto (descripcion, tipo, monto, fecha_gasto) VALUES (%s, %s, %s, %s)'
        val = (descripcion, tipo, monto, fecha_gasto)
        cursor.execute(sql, val)
        self.conexion.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return last_id
    
    def obtener_gasto(self):
        gastos = []
        cursor = self.conexion.cursor()
        sql = 'SELECT * FROM gasto'
        cursor.execute(sql)
        result = cursor.fetchall()
        for row in result:
            gasto= {
                'id_gasto': row[5],
                'descripcion':row[0],
                'tipo':row[1],
                'monto': row[2],
                'fecha_gasto': row[3],
            }
            gastos.append(gasto)
        cursor.close()
        return gastos
    
    def modificar_gasto(self, id_gasto, gasto):
        cursor = self.conexion.cursor()
        sql = 'UPDATE gasto SET descripcion = %s, tipo = %s, fecha_gasto = %s, monto = %s WHERE id_gasto = %s'
        val = (gasto.obtener_descripcion(), gasto.obtener_tipo(), gasto.obtener_fecha(), gasto.obtener_montol(), id_gasto)
        cursor.execute(sql, val)
        self.conexion.commit()
        cursor.close()


    def eliminar_gasto(self, id_gasto):
        cursor = self.conexion.cursor()
        try:
            sql = 'DELETE FROM gasto WHERE id_gasto = %s'
            cursor.execute(sql, (id_gasto,))
            self.conexion.commit()
        except Exception as e:
            self.conexion.rollback()
            print(f'Error al eliminar el gasto: {e}')
        finally:
            cursor.close()


    
#ULTIMO
class CrudPresupuesto:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='floreria_db'
        )

    def generar_presupuesto_mensual(self, total_ventas, monto_gastos):
        presupuesto_mensual = total_ventas - monto_gastos
        return presupuesto_mensual
    
