import mysql.connector
class Floreria:
    def __init__(self):
        self.__host = 'localhost'
        self.__usuario = 'root'
        self.__clave = ''
        self.__esquema= 'floreria_db'
        self.__conexion= 3326


    def iniciar(self):
        self.__conexion = mysql.connector.connect(
            host = self.__host,
            user = self.__usuario,
            password= self.__clave,
            database = self.__esquema,
        )
        cursor = self.__conexion.cursor()
        print(self.__conexion.cursor())
