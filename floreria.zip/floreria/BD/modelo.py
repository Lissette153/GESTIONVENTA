import hashlib




class Producto:

    def __init__(self, nombre, precio, descripcion, categoria, stock, id_producto):
        self.__id = id_producto
        self.__nombre = nombre
        self.__precio = precio
        self.__descripcion = descripcion
        self.__categoria = categoria
        self.__stock = stock

    def obtener_id(self):
        return self.__id
    
    
    def obtener_nombre(self):
        return self.__nombre
    
    def obtener_precio(self):
        return self.__precio
    
    def obtener_descripcion(self):
        return self.__descripcion
    
    def obtener_categoria(self):
        return self.__categoria
    
    def obtener_stock(self):
        return self.__stock
    
    def modificar_nombre(self, nombre):
        self.__nombre = nombre

    def modificar_precio(self, precio):
        self.__precio = precio

    def modificar_stock(self, stock):
        self.__stock = stock


class Venta:
    def __init__(self, id_venta, fecha, total, estado_pago, descripcion, cantidad):
        self.__id = id_venta
        self.__fecha = fecha
        self.__total = total
        self.__estado_pago = estado_pago
        self.__descripcion = descripcion
        self.__cantidad = cantidad 


    def obtener_id(self):
        return self.__id

    def obtener_fecha(self):
        return self.__fecha

    def obtener_total(self):
        return self.__total
    
    def obtener_estado_pago(self):
        return self.__estado_pago
    
    def obtener_descripcion(self):
        return self.__descripcion
    
    def obtener_cantidad(self):
        return self.__cantidad


    


class Gasto:
    def __init__(self, id_gasto, tipo, monto, fecha_gasto, presupuesto):
        self.__id = id_gasto
        self.__descripcion = str()
        self.__tipo = tipo
        self.__monto = monto
        self.__fecha = fecha_gasto
        self.__presupuesto = presupuesto

    def obtener_id(self):
        return self.__id
    
    def obtener_descripcion(self):
        return self.__descripcion
    
    def obtener_tipo(self):
        return self.__tipo
    
    def obtener_monto(self):
        return self.__monto
    
    def obtener_fecha(self):
        return self.__fecha
    
    def obtener_presupuesto(self):
        return self.__presupuesto
    
    def modificar_descripcion(self,descripcion):
        self.__descripcion = descripcion
    
    def modificar_tipo(self, tipo):
        self.__tipo = tipo

    def modificar_fecha(self, fecha_gasto):
        self.__fecha = fecha_gasto

    def modificar_monto(self, monto):
        self.__monto = monto
        

class Presupuesto(Venta, Gasto):
    def __init__(self, id_presupuesto, ventas, gastos, presupuesto_mensual, año, mes):
        self.__id = id_presupuesto
        self.__ventas = ventas
        self.__gastos = gastos
        self.__presupuesto = presupuesto_mensual
        self.__mes = mes

    def obtener_id(self):
        return self.__id

    def obtener_total_ventas(self):
        return self.__total_ventas

    def obtener_cantidad_ventas(self):
        return self.__cantidad_ventas

    def obtener_total_gastos(self):
        return self.__total_gastos

    def obtener_presupuesto_mensual(self):
        return self.__presupuesto

    def obtener_mes(self):
        return self.__mes
    
    def calculo_presupuesto_mensual(self):
        ventT= self.__ventas.obtener_total()
        gastM= self.__gastos.obtener_monto()
        presupuesto_mensual = ventT - gastM
        return presupuesto_mensual





class Item:
    def __init__(self, cantidad, id_venta, id_gasto):
        self.__cantidad = cantidad
        self.__id_venta = id_venta
        self.__id_gasto = id_gasto

    def obtener_cantidad(self):
        return self.__cantidad

    def obtener_id_venta(self):
        return self.__id_venta

    def obtener_id_gasto(self):
        return self.__id_gasto
        
class Usuario:
    def __init__(self, rut, nombre, contraseña,  rol, email, presupuesto):
        self.__rut = rut
        self.__nombre = nombre
        self.__contraseña = contraseña 
        self.__privilegios = str()
        self.__rol = rol
        self.__email = email
        self.__producto = []
        self.__venta = []
        self.__gasto = []
        self.__presupuesto = presupuesto

    def obtener_rut(self):
        return self.__rut

    def obtener_nombre(self):
        return self.__nombre
    
    def obtener_contraseña(self):
        return self.__contraseña
    
    def obtener_privilegio(self):
        return self.__privilegios
    
    def obtener_rol(self):
        return self.__rol
    
    def obtener_email(self):
        return self.__email
    
    def obtener_producto(self):
        return self.__producto
    
    def obtener_venta(self):
        return self.__venta
    
    def obtener_gasto(self):
        return self.__gasto
    
    def obtener_presupuesto(self):
        return self.__presupuesto
    
    def validar_clave(self, contraseña):
        enc = contraseña.encode()
        hash = hashlib.md5(enc).hexdigest()
        return self.__contraseña == hash


class Admin(Usuario):
    def __init__(self, rut, nombre, contraseña,privilegios,  email):
        super().__init__(rut, nombre, contraseña, privilegios,"admin", email)

    def crear_usuario(self, crud_usuario, rut, nombre, contraseña, privilegios, rol , email):
        usuario = Usuario(rut, nombre, contraseña, privilegios, rol, email)
        return crud_usuario.crear_usuario(usuario)

    def obtener_usuario(self, crud_usuario, usuario ):
        return crud_usuario.obtener_usuario(usuario)
    
    def editar_usuario(self, crud_usuario, rut):
        return crud_usuario.modificar_usuario(rut)

    def eliminar_usuario(self, crud_usuario, rut):
        return crud_usuario.eliminar_usuario(rut)

class Local(Usuario):
    
    def __init__(self, rut, nombre, contraseña,privilegios,  email):
        super().__init__(rut, nombre, contraseña,privilegios, 'local', email)
##-----PRODUCTOS------------------------------------------

    def ingresar_producto(self, crud_producto, nombre, precio, descripcion, categoria, stock):
        producto = Producto(nombre, precio, descripcion, categoria, stock)
        return crud_producto.agregar_producto(producto)
    
    def obtener_producto(self, producto, crud_producto):
        return crud_producto.obtener_productos(producto)
    
    def modificar_producto(self, crud_producto, id_producto):
        return crud_producto.modificar_producto(id_producto)
    
    def eliminar_producto(self, crud_producto, id_producto):
        return crud_producto.eliminar_producto(id_producto)
    
    def obtener_inventario(self, crud_producto, nombre, stock, id_producto):
        return crud_producto.obtener_inventario(nombre, stock, id_producto)

#--------------VENTAS----------------------------------------------------------
    def ingresar_venta(self, crud_venta, fecha, total, estado_pago, descripcion, cantidad):
        venta = Venta(fecha, total, estado_pago, descripcion, cantidad)
        return crud_venta.agregar_venta(venta)

    def obtener_venta(self, venta, crud_venta):
        return crud_venta.obtener_venta(venta)
    
    def eliminar_venta(self, crud_venta, id_venta):
        return crud_venta.eliminar_venta(id_venta)
    
    def informe_venta(self, crud_venta, fecha):
        return crud_venta.calcular_monto_total_ventas(fecha)

#-----------------GASTO-------------------------------------------------

    def ingresar_gasto(self, gasto, crud_gasto):
        return crud_gasto.agregar_gasto(gasto)
    

    def visualizar_presupuesto(self, crud_presupuesto):
        return crud_presupuesto.obtener_presupuesto_mensual()