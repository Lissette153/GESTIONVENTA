import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from BD.modelo import *
from BD.crud import *

class VentanaPrincipal(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Floreria La Blanco")
        self.geometry("800x600")
        self.crud_usuario = CrudUsuario()
        self.crud_producto = CrudProducto()
        self.crud_venta = CrudVenta()
        self.crud_gasto = CrudGasto()
        self.crud_presupuesto = CrudPresupuesto()

        self.crear_widgets()

    def crear_widgets(self):
        # Barra de menú
        menubar = tk.Menu(self)
        filemenu = tk.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Salir", command=self.quit)
        menubar.add_cascade(label="Archivo", menu=filemenu)

        # Menú de opciones
        opciones_menu = tk.Menu(menubar, tearoff=0)
        opciones_menu.add_command(label="Ventas", command=self.mostrar_ventana_ventas)
        opciones_menu.add_command(label="Productos", command=self.mostrar_ventana_productos)
        menubar.add_cascade(label="Opciones", menu=opciones_menu)

        self.config(menu=menubar)

    def mostrar_ventana_ventas(self):
        ventana_ventas = VentanaVentas(self)
        ventana_ventas.grab_set()

    def mostrar_ventana_productos(self):
        ventana_productos = VentanaProductos(self)
        ventana_productos.grab_set()

    def ventana_modificar_producto(self):
        ventana_productos = VentanaModificarProducto(self)
        ventana_productos.grab_set()


   

class VentanaVentas(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Ventas")
        self.geometry("600x400")

        self.crud_venta = CrudVenta()

        # Frame para la lista de ventas
        frame_lista_ventas = tk.Frame(self)
        frame_lista_ventas.pack(pady=10)

        # Lista de ventas
        self.lista_ventas = ttk.Treeview(frame_lista_ventas, columns=("id_venta","fecha", "total", "estado_pago", "descripcion", "cantidad"), show="headings")
        self.lista_ventas.heading("id_venta", text="Id_venta")
        self.lista_ventas.heading("fecha", text="Fecha")
        self.lista_ventas.heading("total", text="Total")
        self.lista_ventas.heading("estado_pago", text="Estado de pago")
        self.lista_ventas.heading("descripcion", text="Descripción")
        self.lista_ventas.heading("cantidad", text="Cantidad")
        self.lista_ventas.pack()

        # Botón para agregar una nueva venta
        boton_agregar = tk.Button(self, text="Agregar Venta", command=self.mostrar_ventana_agregar_venta)
        boton_agregar.pack(pady=10)

        # Botón para eliminar una venta
        boton_eliminar = tk.Button(self, text="Eliminar Venta", command=self.eliminar_venta)
        boton_eliminar.pack(pady=10)

        # Botón para generar un informe de ventas
        boton_informe = tk.Button(self, text="Informe de Ventas", command=self.mostrar_ventana_informe_ventas)
        boton_informe.pack(pady=10)

        self.actualizar_lista_ventas()

    def actualizar_lista_ventas(self):
        ventas = self.crud_venta.obtener_venta()
        for venta in ventas:
            self.lista_ventas.insert("", tk.END, values=(venta.obtener_id(), venta.obtener_fecha(), venta.obtener_total(), venta.obtener_estado_pago(), venta.obtener_descripcion(), venta.obtener_cantidad()))

    def mostrar_ventana_agregar_venta(self):
        ventana_agregar_venta = VentanaAgregarVenta(self)
        ventana_agregar_venta.grab_set()
    


    def eliminar_venta(self):
        # Obtener el ID de la venta seleccionada
        seleccion = self.lista_ventas.selection()
        if seleccion:
            id_venta = self.lista_ventas.item(seleccion[0], "values")[0]

            # Confirmar la eliminación
            if messagebox.askyesno("Confirmar Eliminación", "¿Está seguro de que desea eliminar esta venta?"):
                # Eliminar la venta de la base de datos
                self.crud_venta.eliminar_venta(id_venta)

                # Actualizar la lista
                self.actualizar_lista_ventas()
        else:
            messagebox.showwarning("Error", "Seleccione una venta para eliminar.")

    def mostrar_ventana_informe_ventas(self):
        ventana_informe_ventas = VentanaInformeVentas(self)
        ventana_informe_ventas.grab_set()

class VentanaAgregarVenta(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Agregar Venta")
        self.geometry("400x300")

        self.crud_venta = CrudVenta()

        # Etiqueta y campo para la fecha
        etiqueta_fecha = tk.Label(self, text="Fecha:")
        etiqueta_fecha.grid(row=0, column=0, padx=10, pady=10)
        self.campo_fecha = tk.Entry(self)
        self.campo_fecha.grid(row=0, column=1, padx=10, pady=10)

        # Etiqueta y campo para el total
        etiqueta_total = tk.Label(self, text="Total:")
        etiqueta_total.grid(row=1, column=0, padx=10, pady=10)
        self.campo_total = tk.Entry(self)
        self.campo_total.grid(row=1, column=1, padx=10, pady=10)

        # Etiqueta y campo para el estado de pago
        etiqueta_estado_pago = tk.Label(self, text="Estado de pago:")
        etiqueta_estado_pago.grid(row=2, column=0, padx=10, pady=10)
        self.campo_estado_pago = tk.StringVar(self)
        self.campo_estado_pago.set("Seleccionar")
        opciones_estado_pago = ["Pagado", "No pagado"]
        menu_estado_pago = tk.OptionMenu(self, self.campo_estado_pago, *opciones_estado_pago)
        menu_estado_pago.grid(row=2, column=1, padx=10, pady=10)

        # Etiqueta y campo para la descripción
        etiqueta_descripcion = tk.Label(self, text="Descripción:")
        etiqueta_descripcion.grid(row=3, column=0, padx=10, pady=10)
        self.campo_descripcion = tk.Entry(self)
        self.campo_descripcion.grid(row=3, column=1, padx=10, pady=10)

        # Etiqueta y campo para la cantidad
        etiqueta_cantidad = tk.Label(self, text="Cantidad:")
        etiqueta_cantidad.grid(row=4, column=0, padx=10, pady=10)
        self.campo_cantidad = tk.Entry(self)
        self.campo_cantidad.grid(row=4, column=1, padx=10, pady=10)

        # Botón para agregar la venta
        boton_agregar = tk.Button(self, text="Agregar", command=self.agregar_venta)
        boton_agregar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

    def agregar_venta(self):
        # Obtener los datos de la venta
        fecha = self.campo_fecha.get()
        total = self.campo_total.get()
        estado_pago = self.campo_estado_pago.get()
        descripcion = self.campo_descripcion.get()
        cantidad = self.campo_cantidad.get()

        # Validar los datos
        if not fecha or not total or not estado_pago or not descripcion or not cantidad:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return

        # Agregar la venta a la base de datos
        try:
            id_venta = self.crud_venta.agregar_venta(fecha, total, estado_pago, descripcion, cantidad)
            if id_venta:
                messagebox.showinfo("Éxito", "Venta agregada correctamente.")
                self.destroy()
            else:
                messagebox.showerror("Error", "No se pudo agregar la venta.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al agregar la venta: {e}")

class VentanaInformeVentas(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Informe de Ventas")
        self.geometry("400x200")

        self.crud_venta = CrudVenta()

        # Etiqueta y campo para la fecha
        etiqueta_fecha = tk.Label(self, text="Fecha:")
        etiqueta_fecha.grid(row=0, column=0, padx=10, pady=10)
        self.campo_fecha = tk.Entry(self)
        self.campo_fecha.grid(row=0, column=1, padx=10, pady=10)

        # Botón para generar el informe
        boton_generar = tk.Button(self, text="Generar Informe", command=self.generar_informe)
        boton_generar.grid(row=1, column=0, columnspan=2, padx=10, pady=10)

    def generar_informe(self):
        # Obtener la fecha
        fecha = self.campo_fecha.get()

        # Validar la fecha
        if not fecha:
            messagebox.showwarning("Error", "Por favor, ingrese una fecha.")
            return

        # Obtener el informe de ventas
        try:
            ventas, total_ventas = self.crud_venta.calcular_monto_total_ventas(fecha)

            # Mostrar el informe
            ventana_informe = tk.Toplevel(self)
            ventana_informe.title("Informe de Ventas")
            ventana_informe.geometry("400x300")

            # Lista de ventas
            lista_ventas = ttk.Treeview(ventana_informe, columns=("fecha", "total", "estado_pago", "descripcion", "cantidad"), show="headings")
            lista_ventas.heading("fecha", text="Fecha")
            lista_ventas.heading("total", text="Total")
            lista_ventas.heading("estado_pago", text="Estado de pago")
            lista_ventas.heading("descripcion", text="Descripción")
            lista_ventas.heading("cantidad", text="Cantidad")
            lista_ventas.pack()

            for venta in ventas:
                self.lista_ventas.insert(tk.END, values=(venta.get('id_venta'), venta.get('fecha'), venta.get('total'), venta.get('estado_pago'), venta.get('descripcion'), venta.get('cantidad')))


            # Mostrar el total de ventas
            etiqueta_total = tk.Label(ventana_informe, text=f"Total de ventas: {total_ventas}")
            etiqueta_total.pack(pady=10)

        except Exception as e:
            messagebox.showerror("Error", f"Error al generar el informe: {e}")

class VentanaProductos(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Productos")
        self.geometry("600x400")

        self.crud_producto = CrudProducto()

        # Frame para la lista de productos
        frame_lista_productos = tk.Frame(self)
        frame_lista_productos.pack(pady=10)

        # Lista de productos
        self.lista_productos = ttk.Treeview(frame_lista_productos, columns=("id_producto","nombre", "precio", "descripcion", "categoria", "stock"), show="headings")
        self.lista_productos.heading("id_producto", text="ID")
        self.lista_productos.heading("nombre", text="Nombre")
        self.lista_productos.heading("precio", text="Precio")
        self.lista_productos.heading("descripcion", text="Descripción")
        self.lista_productos.heading("categoria", text="Categoría")
        self.lista_productos.heading("stock", text="Stock")
        self.lista_productos.pack()

        # Botón para actualizar la lista
        boton_modificar = tk.Button(self, text="Modificar", command=self.modificar_producto)
        boton_modificar.pack(pady=10)

        # Botón para agregar un nuevo producto
        boton_agregar = tk.Button(self, text="Agregar Producto", command=self.mostrar_ventana_agregar_producto)
        boton_agregar.pack(pady=10)

        # Botón para eliminar un producto
        boton_eliminar = tk.Button(self, text="Eliminar Producto", command=self.eliminar_producto)
        boton_eliminar.pack(pady=10)

        self.actualizar_lista_productos()

    def actualizar_lista_productos(self):
        productos = self.crud_producto.obtener_productos()

        for producto in productos:
            self.lista_productos.insert("", tk.END, values=(producto.obtener_nombre(), producto.obtener_precio(), producto.obtener_descripcion(), producto.obtener_categoria(), producto.obtener_stock()))

    def mostrar_ventana_agregar_producto(self):
        ventana_agregar_producto = VentanaAgregarProducto(self)
        ventana_agregar_producto.grab_set() 
    
    def modificar_producto(self):
        seleccion = self.lista_productos.selection()
        if seleccion:
            id_producto = self.lista_productos.item(seleccion[0], "values")[0]
            producto = self.crud_producto.buscar_producto(id_producto)
            if producto:
                ventana_modificar_producto = VentanaModificarProducto(self, id_producto, producto)
                ventana_modificar_producto.grab_set()
            else:
                messagebox.showerror("Error", "Producto no encontrado.")
        else:
            messagebox.showwarning("Error", "Seleccione un producto para modificar.")

    def eliminar_producto(self):
        # Obtener el ID del producto seleccionado
        seleccion = self.lista_productos.selection()
        if seleccion:
            id_producto = self.lista_productos.item(seleccion[0], "values")[0]

            # Confirmar la eliminación
            if messagebox.askyesno("Confirmar Eliminación", "¿Está seguro de que desea eliminar este producto?"):
                # Eliminar el producto de la base de datos
                self.crud_producto.eliminar_producto(id_producto)

                # Actualizar la lista
                self.actualizar_lista_productos()
        else:
            messagebox.showwarning("Error", "Seleccione un producto para eliminar.")

class VentanaModificarProducto(tk.Toplevel):
    def __init__(self, parent, id_producto, producto):
        super().__init__(parent)
        self.title("Modificar Producto")
        self.geometry("400x300")

        self.crud_producto = CrudProducto()
        self.id_producto = id_producto
        
        etiqueta_nombre = tk.Label(self, text="Nombre:")
        etiqueta_nombre.grid(row=0, column=0, padx=10, pady=10)
        self.campo_nombre = tk.Entry(self)
        self.campo_nombre.grid(row=0, column=1, padx=10, pady=10)

        etiqueta_precio = tk.Label(self, text="Precio:")
        etiqueta_precio.grid(row=1, column=0, padx=10, pady=10)
        self.campo_precio = tk.Entry(self)
        self.campo_precio.grid(row=1, column=1, padx=10, pady=10)


        etiqueta_stock = tk.Label(self, text="Stock:")
        etiqueta_stock.grid(row=4, column=0, padx=10, pady=10)
        self.campo_stock = tk.Entry(self)
        self.campo_stock.grid(row=4, column=1, padx=10, pady=10)

        boton_guardar = tk.Button(self, text="Guardar cambios", command=self.guardar_cambios)
        boton_guardar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

        if producto == None:
            messagebox.showerror("Error", "Producto no encontrado.")
            self.destroy()

    def guardar_cambios(self):
        nombre = self.campo_nombre.get()
        precio = self.campo_precio.get()
        stock = self.campo_stock.get()
   
        if not nombre or not precio or not stock:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return
        
        # Modificar el producto en la base de datos
        try:
            self.crud_producto.modificar_producto( nombre, precio, stock, self.id_producto )
            messagebox.showinfo("Éxito", "Producto modificado correctamente.")
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Error al modificar el producto: {e}")
         




class VentanaAgregarProducto(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Agregar Producto")
        self.geometry("400x300")

        self.crud_producto = CrudProducto()

        # Etiqueta y campo para el nombre
        etiqueta_nombre = tk.Label(self, text="Nombre:")
        etiqueta_nombre.grid(row=0, column=0, padx=10, pady=10)
        self.campo_nombre = tk.Entry(self)
        self.campo_nombre.grid(row=0, column=1, padx=10, pady=10)

        # Etiqueta y campo para el precio
        etiqueta_precio = tk.Label(self, text="Precio:")
        etiqueta_precio.grid(row=1, column=0, padx=10, pady=10)
        self.campo_precio = tk.Entry(self)
        self.campo_precio.grid(row=1, column=1, padx=10, pady=10)

        # Etiqueta y campo para la descripción
        etiqueta_descripcion = tk.Label(self, text="Descripción:")
        etiqueta_descripcion.grid(row=2, column=0, padx=10, pady=10)
        self.campo_descripcion = tk.Entry(self)
        self.campo_descripcion.grid(row=2, column=1, padx=10, pady=10)

        # Etiqueta y campo para la categoría
        etiqueta_categoria = tk.Label(self, text="Categoría:")
        etiqueta_categoria.grid(row=3, column=0, padx=10, pady=10)
        self.campo_categoria = tk.Entry(self)
        self.campo_categoria.grid(row=3, column=1, padx=10, pady=10)

        # Etiqueta y campo para el stock
        etiqueta_stock = tk.Label(self, text="Stock:")
        etiqueta_stock.grid(row=4, column=0, padx=10, pady=10)
        self.campo_stock = tk.Entry(self)
        self.campo_stock.grid(row=4, column=1, padx=10, pady=10)

        # Botón para agregar el producto
        boton_agregar = tk.Button(self, text="Agregar", command=self.agregar_producto)
        boton_agregar.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

    def agregar_producto(self):
        # Obtener los datos del producto
        nombre = self.campo_nombre.get()
        precio = self.campo_precio.get()
        descripcion = self.campo_descripcion.get()
        categoria = self.campo_categoria.get()
        stock = self.campo_stock.get()

        # Validar los datos
        if not nombre or not precio or not descripcion or not categoria or not stock:
            messagebox.showwarning("Error", "Por favor, complete todos los campos.")
            return

        # Agregar el producto a la base de datos
        try:
            id_producto = self.crud_producto.agregar_producto(nombre, precio, descripcion, categoria, stock)
            if id_producto:
                messagebox.showinfo("Éxito", "Producto agregado correctamente.")
                self.destroy()
            else:
                messagebox.showerror("Error", "No se pudo agregar el producto.")
        except Exception as e:
            messagebox.showerror("Error", f"Error al agregar el producto: {e}")

if __name__ == "__main__":
    app = VentanaPrincipal()
    app.mainloop()