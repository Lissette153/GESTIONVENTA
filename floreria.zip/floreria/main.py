import tkinter as tk
from tkinter import ttk
from tkinter import font
from tkinter import messagebox
from formularios.login import Login

if __name__ == "__main__":
    app = Login()
    app.mainloop()